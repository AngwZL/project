/**
 * Copyright (c) 2018-2028, Chill Zhuang 庄骞 (smallchill@163.com).
 * <p>
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * <p>
 * http://www.apache.org/licenses/LICENSE-2.0
 * <p>
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.springblade.modules.ttdf.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springblade.core.mp.support.Condition;
import org.springblade.core.tool.utils.BeanUtil;
import org.springblade.modules.ttdf.entity.Clhsj;
import org.springblade.modules.ttdf.entity.Jcsj;
import org.springblade.modules.ttdf.entity.Yssj;
import org.springblade.modules.ttdf.excel.ClhsjExcel;
import org.springblade.modules.ttdf.excel.ClhsjImportListener;
import org.springblade.modules.ttdf.service.IJcsjService;
import org.springblade.modules.ttdf.vo.ClhsjVO;
import org.springblade.modules.ttdf.mapper.ClhsjMapper;
import org.springblade.modules.ttdf.service.IClhsjService;
import org.springblade.core.mp.base.BaseServiceImpl;
import org.springblade.modules.ttdf.vo.QzxxVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.baomidou.mybatisplus.core.metadata.IPage;

import java.util.*;

/**
 * 处理后数据 服务实现类
 *
 * @author Blade
 * @since 2023-05-09
 */
@Service
public class ClhsjServiceImpl extends ServiceImpl<ClhsjMapper, Clhsj> implements IClhsjService {
	@Autowired
	private IJcsjService jcsjService;
	@Override
	public IPage<ClhsjVO> selectClhsjPage(IPage<ClhsjVO> page, ClhsjVO clhsj) {
		return page.setRecords(baseMapper.selectClhsjPage(page, clhsj));
	}

	@Override
	public void updata(Clhsj clhsj) {
		try {
			baseMapper.updateById(clhsj);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	@Override
	public void removeClhsj(Map<String, Object> removeMap) {
		try {
			baseMapper.deleteBatchIds((Collection<Object>) removeMap);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	@Override
	public Clhsj findById(Integer id) {
		return baseMapper.selectById(id);
	}
	@Override
	public void importClhsj(List<ClhsjExcel> data) {

		List<Clhsj> clhsjList = new ArrayList<>();
		Map<String, Object> removeMap = new HashMap<String, Object>();
		removeMap.put("dfny", ClhsjImportListener.DFNY);
		this.removeByMap(removeMap);
		for (int i=0; i<data.size(); i++) {
			ClhsjExcel clhsjExcel = data.get(i);


				Clhsj clhsj = Objects.requireNonNull(BeanUtil.copy(clhsjExcel, Clhsj.class));
				clhsj.setDfny(ClhsjImportListener.DFNY);
				Jcsj jcsj = new Jcsj();
				System.out.println(clhsj.getYhbh());
				try{
					if(clhsj.getYhbh().equals("转供电")){
						jcsj.setCcbh(clhsj.getDbbh());
						jcsj = jcsjService.getOne(Condition.getQueryWrapper(jcsj));
						clhsj.setQy(jcsj.getQy());
						clhsj.setGdfs("转供电");
					}else{
						jcsj.setYhbh(clhsj.getYhbh());
						jcsj = jcsjService.getOne(Condition.getQueryWrapper(jcsj));
						clhsj.setGdfs("直供电");
						if(jcsj!=null){
							clhsj.setQy(jcsj.getQy());
						}
					}
					clhsjList.add(clhsj);
				}catch (Exception e){

				}
		}
		this.saveBatch(clhsjList);
	}

	public List<Map> hzqdtj(Map<String, Object> map) {
		return baseMapper.hzqdtj(map);
	}

	@Override
	public List<Map> dlyc(ClhsjVO clhsj) {
		return baseMapper.dlyc(clhsj);
	}
}
