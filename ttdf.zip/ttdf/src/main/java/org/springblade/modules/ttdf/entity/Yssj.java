/**
 * Copyright (c) 2018-2028, Chill Zhuang 庄骞 (smallchill@163.com).
 * <p>
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * <p>
 * http://www.apache.org/licenses/LICENSE-2.0
 * <p>
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.springblade.modules.ttdf.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.time.LocalDate;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.NullSerializer;
import org.springblade.core.mp.base.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 原始数据实体类
 *
 * @author Blade
 * @since 2023-05-09
 */
@Data
@TableName("ttdf_yssj")
@ApiModel(value = "Yssj对象", description = "原始数据")
public class Yssj {

    private static final long serialVersionUID = 1L;

    /**
     * id
     */
    @ApiModelProperty(value = "id")
    @TableId(value = "id", type = IdType.AUTO)
  	private Integer id;

	/**
	 * 用户编号
	 */
	@ApiModelProperty(value = "用户编号")
	private String yhbh;
	/**
	 * 起码
	 */
	@ApiModelProperty(value = "起码")
	@JsonSerialize(nullsUsing = NullSerializer.class)
	private Double qm;
	/**
	 * 止码
	 */
	@ApiModelProperty(value = "止码")
	@JsonSerialize(nullsUsing = NullSerializer.class)
	private Double zm;
	/**
	 * 换表记录
	 */
	@ApiModelProperty(value = "换表记录")
	private String hbjl;
	/**
	 * 本次电量
	 */
	@ApiModelProperty(value = "本次电量")
	@JsonSerialize(nullsUsing = NullSerializer.class)
	private Double bcdl;
	/**
	 * 电费金额
	 */
	@ApiModelProperty(value = "电费金额")
	@JsonSerialize(nullsUsing = NullSerializer.class)
	private Double dfje;
	/**
	 * 实收金额
	 */
	@ApiModelProperty(value = "实收金额")
	@JsonSerialize(nullsUsing = NullSerializer.class)
	private Double ssje;
	/**
	 * 缴费方式
	 */
	@ApiModelProperty(value = "缴费方式")
	private String jffs;
	/**
	 * 收费日期
	 */
	@ApiModelProperty(value = "收费日期")
	private String sfrq;
	/**
	 * 电费年月
	 */
	@ApiModelProperty(value = "电费年月")
	private String dfny;
	/**
	 * 营业所
	 */
	@ApiModelProperty(value = "营业所")
	private String yys;

	/**
	 * 区域
	 */
	@ApiModelProperty(value = "区域")
	private String qy;
	/**
	 * 出厂编号
	 */
	@ApiModelProperty(value = "电表编号")
	private String dbbh;
	/**
	 * 表类型
	 */
	@ApiModelProperty(value = "表类型")
	private String blx;
	/**
	 * 用电地址
	 */
	@ApiModelProperty(value = "用电地址")
	private String yddz;
	/**
	 * 用户名称
	 */
	@ApiModelProperty(value = "用户名称")
	private String yhmc;

}
