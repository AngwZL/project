/**
 * Copyright (c) 2018-2028, Chill Zhuang 庄骞 (smallchill@163.com).
 * <p>
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * <p>
 * http://www.apache.org/licenses/LICENSE-2.0
 * <p>
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.springblade.modules.ttdf.service.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springblade.common.constant.CommonConstant;
import org.springblade.core.tool.utils.BeanUtil;
import org.springblade.modules.system.entity.User;
import org.springblade.modules.system.excel.UserExcel;
import org.springblade.modules.ttdf.entity.Clhsj;
import org.springblade.modules.ttdf.excel.YssjExcel;
import org.springblade.modules.ttdf.entity.Yssj;
import org.springblade.modules.ttdf.excel.YssjImportListener;
import org.springblade.modules.ttdf.mapper.YssjMapper;
import org.springblade.modules.ttdf.service.IClhsjService;
import org.springblade.modules.ttdf.service.IYssjService;
import org.springblade.modules.ttdf.vo.YssjVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * 原始数据 服务实现类
 *
 * @author Blade
 * @since 2023-05-09
 */
@Service
public class YssjServiceImpl extends ServiceImpl<YssjMapper, Yssj> implements IYssjService {
	@Autowired
	private IClhsjService clhsjService;
	@Override
	public IPage<YssjVO> selectYssjPage(IPage<YssjVO> page, YssjVO yssj) {
		return page.setRecords(baseMapper.selectYssjPage(page, yssj));
	}
	@Override
	public IPage<YssjVO> selectYssjHBPage(IPage<YssjVO> page, YssjVO yssj) {
		return page.setRecords(baseMapper.selectYssjHBPage(page, yssj));
	}
	@Override
	public boolean removeByQY(Map<String, Object> removeMap) {
		return baseMapper.removeByQY(removeMap);
	}

	@Override
	public List<Yssj> listNoHB(Map<String, Object> map) {
		return baseMapper.listNoHB(map);
	}

	@Override
	public List<Yssj> listHB(Map<String, Object> map) {
		return baseMapper.listHB(map);
	}

	@Override
	public void importYssj(List<YssjExcel> data) {


		/*data.forEach(yssjExcel -> {
			if(yssjExcel.getYys().indexOf('合')>-1 && yssjExcel.getYys().indexOf('计')>-1 ){

			}else{
				Map<String, Object> removeMap = new HashMap<String, Object>();
				removeMap.put("dfny", YssjImportListener.DFNY);
				removeMap.put("qy", YssjImportListener.QY);
				removeMap.put("yhbh", yssjExcel.getYhbh());
				this.removeByQY(removeMap);
			}
		});*/

		List<Yssj> yssjList = new ArrayList<>();
		for (int i=0; i<data.size(); i++) {
			YssjExcel yssjExcel = data.get(i);
			if (i==data.size()-1) {

			} else {
				if(YssjImportListener.QY.equals("阳新")){
					yssjExcel.setYys(yssjExcel.getYys1());
					yssjExcel.setBcdl(yssjExcel.getBcdl1());
					yssjExcel.setDfje(yssjExcel.getDfje1());
					yssjExcel.setSsje(yssjExcel.getSsje1());
					yssjExcel.setDbbh(yssjExcel.getDbbh1());
					yssjExcel.setJffs(yssjExcel.getJffs1());
					yssjExcel.setSfrq(yssjExcel.getSfrq1());
				}
				Yssj yssj = Objects.requireNonNull(BeanUtil.copy(yssjExcel, Yssj.class));
				yssj.setDfny(YssjImportListener.DFNY);
				yssj.setQy(YssjImportListener.QY);
				yssjList.add(yssj);
			}
		}
		this.saveBatch(yssjList);
	}

	public boolean sjcl() {
		//未换表的
		List<Yssj> listNoHB = baseMapper.listNoHB(new HashMap<>());
		for (Yssj yssj : listNoHB){
			Clhsj clhsj = BeanUtil.copy(yssj, Clhsj.class);
			clhsj.setId(null);
			clhsjService.save(clhsj);
		}
		//未换表的
		List<Yssj> listHB = baseMapper.listHB(new HashMap<>());
		for (Yssj yssj : listHB){
			Clhsj clhsj = BeanUtil.copy(yssj, Clhsj.class);
			clhsj.setId(null);

		}
		return true;
	}

	@Override
	public List<Map> queryYhbh(Map<String, Object> map) {
		return baseMapper.queryYhbh(map);
	}
	public List<Map> queryYys(Map<String, Object> map) {
		return baseMapper.queryYys(map);
	}
	public List<Map> queryYddz(Map<String, Object> map) {
		return baseMapper.queryYddz(map);
	}
	public List<Map> queryDbbh(Map<String, Object> map) {
		return baseMapper.queryDbbh(map);
	}
}
