/**
 * Copyright (c) 2018-2028, Chill Zhuang 庄骞 (smallchill@163.com).
 * <p>
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * <p>
 * http://www.apache.org/licenses/LICENSE-2.0
 * <p>
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.springblade.modules.ttdf.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Assert;
import com.baomidou.mybatisplus.extension.service.IService;
import com.baomidou.mybatisplus.extension.toolkit.SqlHelper;
import org.springblade.modules.system.excel.UserExcel;
import org.springblade.modules.ttdf.entity.Yssj;
import org.springblade.modules.ttdf.excel.YssjExcel;
import org.springblade.modules.ttdf.vo.YssjVO;

import java.util.List;
import java.util.Map;

/**
 * 原始数据 服务类
 *
 * @author Blade
 * @since 2023-05-09
 */
public interface IYssjService extends IService<Yssj> {

	/**
	 * 自定义分页
	 *
	 * @param page
	 * @param yssj
	 * @return
	 */
	IPage<YssjVO> selectYssjPage(IPage<YssjVO> page, YssjVO yssj);

	IPage<YssjVO> selectYssjHBPage(IPage<YssjVO> page, YssjVO yssj);

	void importYssj(List<YssjExcel> data);
	boolean removeByQY(Map<String, Object> removeMap);

	boolean sjcl();

	List<Yssj> listNoHB(Map<String, Object> map);
	List<Yssj> listHB(Map<String, Object> map);

	List<Map> queryYhbh(Map<String, Object> map);
	List<Map> queryYys(Map<String, Object> map);
	List<Map> queryYddz(Map<String, Object> map);
	List<Map> queryDbbh(Map<String, Object> map);

}
