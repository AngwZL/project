/**
 * Copyright (c) 2018-2028, Chill Zhuang 庄骞 (smallchill@163.com).
 * <p>
 * Licensed under the GNU LESSER GENERAL PUBLIC LICENSE 3.0;
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * <p>
 * http://www.gnu.org/licenses/lgpl.html
 * <p>
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.springblade.modules.ttdf.controller;

import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.EasyExcelFactory;
import com.alibaba.excel.ExcelReader;
import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.read.metadata.ReadSheet;
import com.alibaba.excel.write.metadata.WriteSheet;
import com.alibaba.excel.write.metadata.WriteTable;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.google.common.collect.Lists;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import lombok.AllArgsConstructor;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import lombok.SneakyThrows;
import org.apache.commons.codec.Charsets;
import org.springblade.core.mp.support.Condition;
import org.springblade.core.mp.support.Query;
import org.springblade.core.secure.BladeUser;
import org.springblade.core.secure.utils.SecureUtil;
import org.springblade.core.tool.api.R;
import org.springblade.core.tool.constant.BladeConstant;
import org.springblade.core.tool.utils.Func;
import org.springblade.modules.system.entity.User;
import org.springblade.modules.system.excel.UserExcel;
import org.springblade.modules.ttdf.entity.Yssj;
import org.springblade.modules.ttdf.excel.*;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.RequestParam;
import com.baomidou.mybatisplus.core.metadata.IPage;
import org.springblade.modules.ttdf.entity.Tzxx;
import org.springblade.modules.ttdf.vo.TzxxVO;
import org.springblade.modules.ttdf.service.ITzxxService;
import org.springblade.core.boot.ctrl.BladeController;
import org.springframework.web.multipart.MultipartFile;
import springfox.documentation.annotations.ApiIgnore;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * 台账信息 控制器
 *
 * @author Blade
 * @since 2023-05-19
 */
@RestController
@AllArgsConstructor
@RequestMapping("/ttdf/tzxx")
@Api(value = "台账信息", tags = "台账信息接口")
public class TzxxController extends BladeController {

	private ITzxxService tzxxService;

	/**
	 * 详情
	 */
	@GetMapping("/detail")
	@ApiOperationSupport(order = 1)
	@ApiOperation(value = "详情", notes = "传入tzxx")
	public R<Tzxx> detail(Tzxx tzxx) {
		Tzxx detail = tzxxService.getOne(Condition.getQueryWrapper(tzxx));
		return R.data(detail);
	}

	/**
	 * 数量
	 */
	@GetMapping("/count")
	@ApiOperationSupport(order = 1)
	@ApiOperation(value = "详情", notes = "传入tzxx")
	public R<Long> count(String dfny) {
		Tzxx tzxx = new Tzxx();
		tzxx.setYf(dfny);
		long count = tzxxService.count(Condition.getQueryWrapper(tzxx));
		return R.data(count);
	}

	/**
	 * 自定义分页 台账信息
	 */
	@GetMapping("/page")
	@ApiOperationSupport(order = 3)
	@ApiOperation(value = "分页", notes = "传入tzxx")
	public R<IPage<TzxxVO>> page(TzxxVO tzxx, Query query) {
		IPage<TzxxVO> pages = tzxxService.selectTzxxPage(Condition.getPage(query), tzxx);
		return R.data(pages);
	}

	/**
	 * 新增 台账信息
	 */
	@PostMapping("/save")
	@ApiOperationSupport(order = 4)
	@ApiOperation(value = "新增", notes = "传入tzxx")
	public R save(@Valid @RequestBody Tzxx tzxx) {
		return R.status(tzxxService.save(tzxx));
	}

	/**
	 * 修改 台账信息
	 */
	@PostMapping("/update")
	@ApiOperationSupport(order = 5)
	@ApiOperation(value = "修改", notes = "传入tzxx")
	public R update(@Valid @RequestBody Tzxx tzxx) {
		return R.status(tzxxService.updateById(tzxx));
	}

	/**
	 * 新增或修改 台账信息
	 */
	@PostMapping("/submit")
	@ApiOperationSupport(order = 6)
	@ApiOperation(value = "新增或修改", notes = "传入tzxx")
	public R submit(@Valid @RequestBody Tzxx tzxx) {
		return R.status(tzxxService.saveOrUpdate(tzxx));
	}


	/**
	 * 删除 台账信息
	 */
	@PostMapping("/remove")
	@ApiOperationSupport(order = 7)
	@ApiOperation(value = "逻辑删除", notes = "传入ids")
	public R remove(@ApiParam(value = "主键集合", required = true) @RequestParam String ids) {
		return R.status(tzxxService.removeByIds(Func.toLongList(ids)));
	}

	/**
	 * 生成台账
	 */
	@PostMapping("/sctz")
	@ApiOperationSupport(order = 4)
	@ApiOperation(value = "生成台账")
	public R sjcl(String qy, String dfny, String fg) throws ParseException {

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy年M月d日");
		Date date = sdf.parse(dfny+"1日");				//本次抄表日
		Calendar calendar=Calendar.getInstance();
		calendar.setTime(date);
		calendar.add(Calendar.MONTH, -1);
		Date date1 = calendar.getTime();							//上次抄表日

		SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy/M/d");
		String bccb = sdf1.format(date);							//本次抄表日
		String sccb = sdf1.format(date1);							//上次抄表日
		int days = (int) ((date.getTime() - date1.getTime()) / (24 * 60 * 60 * 1000));

		Map<String, Object> map = new HashMap<>();
		if("1".equals(fg)){
			Tzxx tzxx = new Tzxx();
			tzxx.setYf(dfny);
			tzxxService.remove(Condition.getQueryWrapper(tzxx));
		}
		map.put("dfny",dfny);
		List<Tzxx> listHB1 = tzxxService.sctzList1(map);
		List<Tzxx> listHB2 = tzxxService.sctzList2(map);
		listHB1.addAll(listHB2);
		for(Tzxx tzxx : listHB1){
			System.out.println(tzxx.getYhbh());
			tzxx.setId(null);
			tzxx.setYf(dfny);
			Double ftxs = Double.parseDouble(tzxx.getFtxs().replace("%",""))/100;	//分摊系数
			Double jine = Double.parseDouble(tzxx.getJine());										//电费金额
			Double ydl = Double.parseDouble(tzxx.getYdl());											//用电量
			Double ftjcsj = tzxx.getJczj();															//分摊基础数据
																						//上月天数
			/*Double dfftYd4g = Double.parseDouble(tzxx.getYdftbl4g().replace("%",""))/100;			//移动4g分摊比例
			Double dfftLt4g = Double.parseDouble(tzxx.getLtftbl4g().replace("%",""))/100;			//联通4g分摊比例
			Double dfftDx4g = Double.parseDouble(tzxx.getDxftbl4g().replace("%",""))/100;			//电信4g分摊比例
			Double tzyw = Double.parseDouble(tzxx.getTzywbl().replace("%",""))/100;			//拓展业务分摊比例
			Double dfftYd5g = Double.parseDouble(tzxx.getYdftbl5g().replace("%",""))/100;			//移动5g分摊比例
			Double dfftLt5g = Double.parseDouble(tzxx.getLtftbl5g().replace("%",""))/100;			//联通5g分摊比例
			Double dfftDx5g = Double.parseDouble(tzxx.getDxftbl5g().replace("%",""))/100;			//电信5g分摊比例*/
			if(tzxx.getJczj()==0d || tzxx.getJczj()==0 || tzxx.getJczj()==null){
				tzxx.setBccbrq(bccb);
				tzxx.setSccbrq(sccb);
				Double dfftYd4g = 0d;
				Double dfftLt4g = 0d;			//联通4g分摊比例
				Double dfftDx4g = 0d;		//电信4g分摊比例
				Double tzyw = 0d;			//拓展业务分摊比例
				Double dfftYd5g = 0d;		//移动5g分摊比例
				Double dfftLt5g = 0d;			//联通5g分摊比例
				Double dfftDx5g = 0d;			//电信5g分摊比例
				tzxx.setFtxszdje(String.format("%.2f",jine*ftxs));//分摊系数账单金额
				tzxx.setJydfl(String.format("%.2f",ftjcsj*54*24*days/1000*1.26*0.78));//校验电费列
				tzxx.setDfftYd4g(String.format("%.2f",ftxs*jine*dfftYd4g));//电费分摊-移动4g
				tzxx.setDfftLt4g(String.format("%.2f",ftxs*jine*dfftLt4g));//电费分摊-联通4g
				tzxx.setDfftDx4g(String.format("%.2f",ftxs*jine*dfftDx4g));//电费分摊-电信4g
				tzxx.setDfftTzyw(String.format("%.2f",ftxs*jine*tzyw));//电费分摊-拓展业务
				tzxx.setDfftYd5g(String.format("%.2f",ftxs*jine*dfftYd5g));//电费分摊-移动5g
				tzxx.setDfftLt5g(String.format("%.2f",ftxs*jine*dfftLt5g));//电费分摊-联通5g
				tzxx.setDfftDx5g(String.format("%.2f",ftxs*jine*dfftDx5g));//电费分摊-电信5g
				tzxx.setDfftHjdf(String.format("%.2f",jine));//电费分摊-合计电费
				tzxx.setDlftYd4g(String.format("%.2f",ftxs*ydl*dfftYd4g));//电量分摊-移动4g
				tzxx.setDlftLt4g(String.format("%.2f",ftxs*ydl*dfftLt4g));//电量分摊-联通4g
				tzxx.setDlftDx4g(String.format("%.2f",ftxs*ydl*dfftDx4g));//电量分摊-电信4g
				tzxx.setDlftTzyw(String.format("%.2f",ftxs*ydl*tzyw));//电量分摊-拓展业务
				tzxx.setDlftYd5g(String.format("%.2f",ftxs*ydl*dfftYd5g));//电量分摊-移动5g
				tzxx.setDlftLt5g(String.format("%.2f",ftxs*ydl*dfftLt5g));//电量分摊-联通5g
				tzxx.setDlftDx5g(String.format("%.2f",ftxs*ydl*dfftDx5g));//电量分摊-电信5g
				tzxx.setDlftHjdf(String.format("%.2f",ydl));//电量分摊-合计总电量
				tzxx.setFthdfYd4g(String.format("%.2f",(jine-ydl*0.0188)*ftxs*dfftYd4g));	//分摊后电费(含税不含农网费)4G_移动
				tzxx.setFthdfLt4g(String.format("%.2f",(jine-ydl*0.0188)*ftxs*dfftLt4g));	//分摊后电费(含税不含农网费)4G_联通
				tzxx.setFthdfDx4g(String.format("%.2f",(jine-ydl*0.0188)*ftxs*dfftDx4g));	//分摊后电费(含税不含农网费)4G_电信
				tzxx.setFthdfTzyw(String.format("%.2f",(jine-ydl*0.0188)*ftxs*tzyw));	//分摊后电费(含税不含农网费)4G_拓展业务
				tzxx.setFthdfYd5g(String.format("%.2f",(jine-ydl*0.0188)*ftxs*dfftYd5g));	//分摊后电费(含税不含农网费)5G_移动
				tzxx.setFthdfLt5g(String.format("%.2f",(jine-ydl*0.0188)*ftxs*dfftLt5g));	//分摊后电费(含税不含农网费)5G_联通
				tzxx.setFthdfDx5g(String.format("%.2f",(jine-ydl*0.0188)*ftxs*dfftDx5g));	//分摊后电费(含税不含农网费)5G_电信
				tzxx.setFthnwfYd(String.format("%.2f",ydl*0.0188*ftxs*dfftYd4g));					//分摊后农网费_移动
				tzxx.setFthnwfLt(String.format("%.2f",ydl*0.0188*ftxs*dfftLt4g));					//分摊后农网费_联通
				tzxx.setFthnwfDx(String.format("%.2f",ydl*0.0188*ftxs*dfftDx4g));					//分摊后农网费_电信
				tzxx.setFthnwfTzyw(String.format("%.2f",ydl*0.0188*ftxs*tzyw));						//分摊后农网费_拓展业务
				tzxx.setFthnwfHj(String.format("%.2f",ydl*0.0188*ftxs*dfftYd4g+ydl*0.0188*ftxs*dfftLt4g+ydl*0.0188*ftxs*dfftDx4g+ydl*0.0188*ftxs*tzyw));					//分摊后农网费_合计
				tzxx.setSfyzYd4g(String.format("%.2f",dfftYd4g*ydl*0.0188*1.1479*ftxs));					//税负因子_移动4G税负因子
				tzxx.setSfyzLt4g(String.format("%.2f",dfftLt4g*ydl*0.0188*1.1479*ftxs));					//税负因子_联通4G税负因子
				tzxx.setSfyzDx4g(String.format("%.2f",dfftDx4g*ydl*0.0188*1.1479*ftxs));					//税负因子_电信4G税负因子
				tzxx.setSfyzYd5g(String.format("%.2f",dfftYd5g*ydl*0.0188*1.1479*ftxs));					//税负因子_移动5G税负因子
				tzxx.setSfyzLt5g(String.format("%.2f",dfftLt5g*ydl*0.0188*1.1479*ftxs));					//税负因子_联通5G税负因子
				tzxx.setSfyzDx5g(String.format("%.2f",dfftDx5g*ydl*0.0188*1.1479*ftxs));					//税负因子_电信5G税负因子
				tzxx.setSfyzZj(String.format("%.2f",dfftYd4g*ydl*0.0188*1.1479*ftxs+dfftLt4g*ydl*0.0188*1.1479*ftxs+dfftDx4g*ydl*0.0188*1.1479*ftxs+
					dfftYd5g*ydl*0.0188*1.1479*ftxs+dfftLt5g*ydl*0.0188*1.1479*ftxs+dfftDx5g*ydl*0.0188*1.1479*ftxs));					//税负因子_税负因子总计
				tzxx.setSfyzYd4gFt(String.format("%.2f",(jine-ydl*0.0188)*ftxs*dfftYd4g+dfftYd4g*ydl*0.0188*1.1479*ftxs));				//税负因子_移动4G分摊
				tzxx.setSfyzLt4gFt(String.format("%.2f",(jine-ydl*0.0188)*ftxs*dfftLt4g+dfftLt4g*ydl*0.0188*1.1479*ftxs));				//税负因子_联通4G分摊
				tzxx.setSfyzDx4gFt(String.format("%.2f",(jine-ydl*0.0188)*ftxs*dfftDx4g+dfftDx4g*ydl*0.0188*1.1479*ftxs));				//税负因子_电信4G分摊
				tzxx.setSfyzTznyFt(String.format("%.2f",ftxs*jine*tzyw));				//税负因子_拓展能源
				tzxx.setSfyzYd5gFt(String.format("%.2f",(jine-ydl*0.0188)*ftxs*dfftYd5g+dfftYd5g*ydl*0.0188*1.1479*ftxs));				//税负因子_移动5G分摊
				tzxx.setSfyzLt5gFt(String.format("%.2f",(jine-ydl*0.0188)*ftxs*dfftLt5g+dfftLt5g*ydl*0.0188*1.1479*ftxs));				//税负因子_联通5G分摊
				tzxx.setSfyzDx5gFt(String.format("%.2f",(jine-ydl*0.0188)*ftxs*dfftDx5g+dfftDx5g*ydl*0.0188*1.1479*ftxs));				//税负因子_电信5G分摊
				tzxx.setSfyzFthj(String.format("%.2f",jine));					//税负因子_最终分摊合计
			}else{
				tzxx.setBccbrq(bccb);
				tzxx.setSccbrq(sccb);
				Double dfftYd4g = tzxx.getYd4g()/tzxx.getJczj();
				Double dfftLt4g = tzxx.getLt4g()/tzxx.getJczj();			//联通4g分摊比例
				Double dfftDx4g = tzxx.getDx4g()/tzxx.getJczj();		//电信4g分摊比例
				Double tzyw = Double.parseDouble(tzxx.getTzywjs())/tzxx.getJczj();			//拓展业务分摊比例
				Double dfftYd5g = tzxx.getYd5g()/tzxx.getJczj();		//移动5g分摊比例
				Double dfftLt5g = tzxx.getLt5g()/tzxx.getJczj();			//联通5g分摊比例
				Double dfftDx5g = tzxx.getDx5g()/tzxx.getJczj();			//电信5g分摊比例
				tzxx.setFtxszdje(String.format("%.2f",jine*ftxs));//分摊系数账单金额
				tzxx.setJydfl(String.format("%.2f",ftjcsj*54*24*days/1000*1.26*0.78));//校验电费列
				tzxx.setDfftYd4g(String.format("%.2f",ftxs*jine*dfftYd4g));//电费分摊-移动4g
				tzxx.setDfftLt4g(String.format("%.2f",ftxs*jine*dfftLt4g));//电费分摊-联通4g
				tzxx.setDfftDx4g(String.format("%.2f",ftxs*jine*dfftDx4g));//电费分摊-电信4g
				tzxx.setDfftTzyw(String.format("%.2f",ftxs*jine*tzyw));//电费分摊-拓展业务
				tzxx.setDfftYd5g(String.format("%.2f",ftxs*jine*dfftYd5g));//电费分摊-移动5g
				tzxx.setDfftLt5g(String.format("%.2f",ftxs*jine*dfftLt5g));//电费分摊-联通5g
				tzxx.setDfftDx5g(String.format("%.2f",ftxs*jine*dfftDx5g));//电费分摊-电信5g
				tzxx.setDfftHjdf(String.format("%.2f",ftxs*jine*dfftYd4g+ftxs*jine*dfftLt4g+ftxs*jine*dfftDx4g+ftxs*jine*tzyw+ftxs*jine*dfftYd5g+ftxs*jine*dfftLt5g+ftxs*jine*dfftDx5g));//电费分摊-合计电费
				tzxx.setDlftYd4g(String.format("%.2f",ftxs*ydl*dfftYd4g));//电量分摊-移动4g
				tzxx.setDlftLt4g(String.format("%.2f",ftxs*ydl*dfftLt4g));//电量分摊-联通4g
				tzxx.setDlftDx4g(String.format("%.2f",ftxs*ydl*dfftDx4g));//电量分摊-电信4g
				tzxx.setDlftTzyw(String.format("%.2f",ftxs*ydl*tzyw));//电量分摊-拓展业务
				tzxx.setDlftYd5g(String.format("%.2f",ftxs*ydl*dfftYd5g));//电量分摊-移动5g
				tzxx.setDlftLt5g(String.format("%.2f",ftxs*ydl*dfftLt5g));//电量分摊-联通5g
				tzxx.setDlftDx5g(String.format("%.2f",ftxs*ydl*dfftDx5g));//电量分摊-电信5g
				tzxx.setDlftHjdf(String.format("%.2f",ftxs*ydl*dfftYd4g+ftxs*ydl*dfftLt4g+ftxs*ydl*dfftDx4g+ftxs*ydl*tzyw+ftxs*ydl*dfftYd5g+ftxs*ydl*dfftLt5g+ftxs*ydl*dfftDx5g));//电量分摊-合计总电量
				tzxx.setFthdfYd4g(String.format("%.2f",(jine-ydl*0.0188)*ftxs*dfftYd4g));	//分摊后电费(含税不含农网费)4G_移动
				tzxx.setFthdfLt4g(String.format("%.2f",(jine-ydl*0.0188)*ftxs*dfftLt4g));	//分摊后电费(含税不含农网费)4G_联通
				tzxx.setFthdfDx4g(String.format("%.2f",(jine-ydl*0.0188)*ftxs*dfftDx4g));	//分摊后电费(含税不含农网费)4G_电信
				tzxx.setFthdfTzyw(String.format("%.2f",(jine-ydl*0.0188)*ftxs*tzyw));	//分摊后电费(含税不含农网费)4G_拓展业务
				tzxx.setFthdfYd5g(String.format("%.2f",(jine-ydl*0.0188)*ftxs*dfftYd5g));	//分摊后电费(含税不含农网费)5G_移动
				tzxx.setFthdfLt5g(String.format("%.2f",(jine-ydl*0.0188)*ftxs*dfftLt5g));	//分摊后电费(含税不含农网费)5G_联通
				tzxx.setFthdfDx5g(String.format("%.2f",(jine-ydl*0.0188)*ftxs*dfftDx5g));	//分摊后电费(含税不含农网费)5G_电信
				tzxx.setFthnwfYd(String.format("%.2f",ydl*0.0188*ftxs*dfftYd4g));					//分摊后农网费_移动
				tzxx.setFthnwfLt(String.format("%.2f",ydl*0.0188*ftxs*dfftLt4g));					//分摊后农网费_联通
				tzxx.setFthnwfDx(String.format("%.2f",ydl*0.0188*ftxs*dfftDx4g));					//分摊后农网费_电信
				tzxx.setFthnwfTzyw(String.format("%.2f",ydl*0.0188*ftxs*tzyw));						//分摊后农网费_拓展业务
				tzxx.setFthnwfHj(String.format("%.2f",ydl*0.0188*ftxs*dfftYd4g+ydl*0.0188*ftxs*dfftLt4g+ydl*0.0188*ftxs*dfftDx4g+ydl*0.0188*ftxs*tzyw));					//分摊后农网费_合计
				tzxx.setSfyzYd4g(String.format("%.2f",dfftYd4g*ydl*0.0188*1.1479*ftxs));					//税负因子_移动4G税负因子
				tzxx.setSfyzLt4g(String.format("%.2f",dfftLt4g*ydl*0.0188*1.1479*ftxs));					//税负因子_联通4G税负因子
				tzxx.setSfyzDx4g(String.format("%.2f",dfftDx4g*ydl*0.0188*1.1479*ftxs));					//税负因子_电信4G税负因子
				tzxx.setSfyzYd5g(String.format("%.2f",dfftYd5g*ydl*0.0188*1.1479*ftxs));					//税负因子_移动5G税负因子
				tzxx.setSfyzLt5g(String.format("%.2f",dfftLt5g*ydl*0.0188*1.1479*ftxs));					//税负因子_联通5G税负因子
				tzxx.setSfyzDx5g(String.format("%.2f",dfftDx5g*ydl*0.0188*1.1479*ftxs));					//税负因子_电信5G税负因子
				tzxx.setSfyzZj(String.format("%.2f",dfftYd4g*ydl*0.0188*1.1479*ftxs+dfftLt4g*ydl*0.0188*1.1479*ftxs+dfftDx4g*ydl*0.0188*1.1479*ftxs+
					dfftYd5g*ydl*0.0188*1.1479*ftxs+dfftLt5g*ydl*0.0188*1.1479*ftxs+dfftDx5g*ydl*0.0188*1.1479*ftxs));					//税负因子_税负因子总计
				tzxx.setSfyzYd4gFt(String.format("%.2f",(jine-ydl*0.0188)*ftxs*dfftYd4g+dfftYd4g*ydl*0.0188*1.1479*ftxs));				//税负因子_移动4G分摊
				tzxx.setSfyzLt4gFt(String.format("%.2f",(jine-ydl*0.0188)*ftxs*dfftLt4g+dfftLt4g*ydl*0.0188*1.1479*ftxs));				//税负因子_联通4G分摊
				tzxx.setSfyzDx4gFt(String.format("%.2f",(jine-ydl*0.0188)*ftxs*dfftDx4g+dfftDx4g*ydl*0.0188*1.1479*ftxs));				//税负因子_电信4G分摊
				tzxx.setSfyzTznyFt(String.format("%.2f",ftxs*jine*tzyw));				//税负因子_拓展能源
				tzxx.setSfyzYd5gFt(String.format("%.2f",(jine-ydl*0.0188)*ftxs*dfftYd5g+dfftYd5g*ydl*0.0188*1.1479*ftxs));				//税负因子_移动5G分摊
				tzxx.setSfyzLt5gFt(String.format("%.2f",(jine-ydl*0.0188)*ftxs*dfftLt5g+dfftLt5g*ydl*0.0188*1.1479*ftxs));				//税负因子_联通5G分摊
				tzxx.setSfyzDx5gFt(String.format("%.2f",(jine-ydl*0.0188)*ftxs*dfftDx5g+dfftDx5g*ydl*0.0188*1.1479*ftxs));				//税负因子_电信5G分摊
				tzxx.setSfyzFthj(String.format("%.2f",(jine-ydl*0.0188)*ftxs*dfftYd4g+dfftYd4g*ydl*0.0188*1.1479*ftxs
					+(jine-ydl*0.0188)*ftxs*dfftLt4g+dfftLt4g*ydl*0.0188*1.1479*ftxs
					+(jine-ydl*0.0188)*ftxs*dfftDx4g+dfftDx4g*ydl*0.0188*1.1479*ftxs
					+ ftxs*jine*tzyw
					+(jine-ydl*0.0188)*ftxs*dfftYd5g+dfftYd5g*ydl*0.0188*1.1479*ftxs
					+(jine-ydl*0.0188)*ftxs*dfftLt5g+dfftLt5g*ydl*0.0188*1.1479*ftxs
					+(jine-ydl*0.0188)*ftxs*dfftDx5g+dfftDx5g*ydl*0.0188*1.1479*ftxs)
				);					//税负因子_最终分摊合计
			}

		}
		tzxxService.saveBatch(listHB1);
		return R.data(true);
	}


	/**
	 * 台账统计
	 */
	@GetMapping("/tzxxtj")
	public R<Map> tzxxtj(@RequestParam Map<String, Object> params) {
		Map<String, Object> result = new HashMap<>();
		List<Map> list = tzxxService.tzxxtj(params);
		if(list.size()>0){
			result = list.get(0);
		}
		return R.data(result);
	}


	/**
	 * 导出台账
	 */
	@SneakyThrows
	@GetMapping("export-tzxx")
	@ApiOperationSupport(order = 13)
	@ApiOperation(value = "导出台账", notes = "传入dfny")
	public void exportTzxx(@ApiIgnore @RequestParam String dfny, HttpServletResponse response) {
		Tzxx tzxx = new Tzxx();
		tzxx.setYf(dfny);
		List<TzxxExcel> tzxxList = tzxxService.exportTzxx(tzxx);

		response.setContentType("application/vnd.ms-excel");
		response.setCharacterEncoding(Charsets.UTF_8.name());
		String fileName = URLEncoder.encode(dfny+"台账", Charsets.UTF_8.name());
		response.setHeader("Content-disposition", "attachment;filename=" + fileName + ".xlsx");
		OutputStream out = response.getOutputStream();

		ExcelWriter writer = EasyExcelFactory.write(out).build();

		WriteSheet sheet1 = new WriteSheet();
		sheet1.setSheetName(dfny+"台账");
		sheet1.setSheetNo(0);
		// 创建一个表格，用于 Sheet 中使用
		WriteTable table = new WriteTable( );
		table.setTableNo(1);
		table.setHead(head(""));
		// 写数据

		//writer.write(contentData(), sheet1, table);
		writer.write(tzxxList, sheet1, table);

		writer.finish();
		out.close();
	}


	/**
	 * 导出台账
	 */
	@SneakyThrows
	@GetMapping("export-qrd")
	@ApiOperationSupport(order = 13)
	@ApiOperation(value = "导出确认单", notes = "传入dfny")
	public void exportQrd(@ApiIgnore @RequestParam String dfny,String yys, HttpServletResponse response) {
		Tzxx tzxx = new Tzxx();
		tzxx.setYf(dfny);
		tzxx.setYys(yys);

		if(yys.equals("电信")){
			tzxx.setDfftDx4g("1");
			List<TzxxExcel> tzxxList1 = tzxxService.exportQrd(tzxx);
			tzxx.setDfftDx4g(null);
			tzxx.setDfftDx5g("1");
			List<TzxxExcel> tzxxList2 = tzxxService.exportQrd(tzxx);
			tzxx.setDfftDx5g(null);
			response.setContentType("application/vnd.ms-excel");
			response.setCharacterEncoding(Charsets.UTF_8.name());
			String fileName = URLEncoder.encode(dfny+yys+"确认单", Charsets.UTF_8.name());
			response.setHeader("Content-disposition", "attachment;filename=" + fileName + ".xlsx");
			OutputStream out = response.getOutputStream();
			ExcelWriter writer = EasyExcelFactory.write(out).build();

			WriteSheet sheet1 = new WriteSheet();
			sheet1.setSheetName(dfny+yys+"4G");
			sheet1.setSheetNo(0);
			// 创建一个表格，用于 Sheet 中使用
			WriteTable table = new WriteTable( );
			table.setTableNo(1);
			table.setHead(head("电信"));

			WriteSheet sheet2 = new WriteSheet();
			sheet2.setSheetName(dfny+yys+"5G");
			sheet2.setSheetNo(1);
			// 创建一个表格，用于 Sheet 中使用
			WriteTable table2 = new WriteTable( );
			table2.setTableNo(1);
			table2.setHead(head("电信"));
			// 写数据
			//writer.write(contentData(), sheet1, table);
			writer.write(tzxxList1, sheet1, table);
			writer.write(tzxxList2, sheet2, table2);
			writer.finish();
			out.close();
		}else if(yys.equals("联通")){
			List<TzxxExcel> tzxxList = tzxxService.exportQrd(tzxx);
			response.setContentType("application/vnd.ms-excel");
			response.setCharacterEncoding(Charsets.UTF_8.name());
			String fileName = URLEncoder.encode(dfny+yys+"确认单", Charsets.UTF_8.name());
			response.setHeader("Content-disposition", "attachment;filename=" + fileName + ".xlsx");
			OutputStream out = response.getOutputStream();
			ExcelWriter writer = EasyExcelFactory.write(out).build();
			WriteSheet sheet1 = new WriteSheet();
			sheet1.setSheetName(dfny+yys);
			sheet1.setSheetNo(0);
			// 创建一个表格，用于 Sheet 中使用
			WriteTable table = new WriteTable( );
			table.setTableNo(1);
			table.setHead(head("联通"));
			// 写数据
			//writer.write(contentData(), sheet1, table);
			writer.write(tzxxList, sheet1, table);
			writer.finish();
			out.close();
		}else{
			List<TzxxExcelYD> tzxxList = tzxxService.exportQrdYD(tzxx);
			response.setContentType("application/vnd.ms-excel");
			response.setCharacterEncoding(Charsets.UTF_8.name());
			String fileName = URLEncoder.encode(dfny+yys+"确认单", Charsets.UTF_8.name());
			response.setHeader("Content-disposition", "attachment;filename=" + fileName + ".xlsx");
			OutputStream out = response.getOutputStream();
			ExcelWriter writer = EasyExcelFactory.write(out).build();
			WriteSheet sheet1 = new WriteSheet();
			sheet1.setSheetName(dfny+yys);
			sheet1.setSheetNo(0);
			// 创建一个表格，用于 Sheet 中使用
			WriteTable table = new WriteTable( );
			table.setTableNo(1);
			table.setHead(head("移动"));
			// 写数据
			//writer.write(contentData(), sheet1, table);
			writer.write(tzxxList, sheet1, table);
			writer.finish();
			out.close();
		}


	}

	private static List <List<String>> head(String yys){
		List<List<String>> headTitles = Lists.newArrayList();
		String first1 = "电表信息",first2 = "站点信息",first3 = "分摊基础数据（直流负荷）",first4 = "5G电流",
			first5 = "分摊比例（4G）",first6 = "5G分摊",first7 = "抄表信息",first8 = " ",first9 = " ",first10 = "电费分摊",
			first11 = "电量",first12 = "分摊后电费(含税不含农网费)4G",first13 = "分摊后电费(含税不含农网费)5G",first14 = "分摊后农网费",
			first15 = " ",first16 = "税负因子",first17 = " ",first18 = " ",first19 = " ",first20 = " ";

		headTitles.add( Lists.newArrayList( first1,"区域供电所") );
		headTitles.add( Lists.newArrayList( first1,"电表编号") );

		headTitles.add( Lists.newArrayList(first2,"区县") );
		headTitles.add( Lists.newArrayList(first2,"月份") );
		headTitles.add( Lists.newArrayList(first2,"站点编码") );
		headTitles.add( Lists.newArrayList(first2,"站名") );
		if(yys.equals("移动")){
			headTitles.add( Lists.newArrayList(first2,"三费报账点") );
			headTitles.add( Lists.newArrayList(first2,"三费区域") );
		}
		headTitles.add( Lists.newArrayList(first2,"分摊系数") );
		headTitles.add( Lists.newArrayList(first2,"供电用户号（客编）") );
		headTitles.add( Lists.newArrayList(first2,"运营商") );
		headTitles.add( Lists.newArrayList(first2,"供电方式") );

		headTitles.add( Lists.newArrayList(first3,"总计") );
		headTitles.add( Lists.newArrayList(first3,"移动") );
		headTitles.add( Lists.newArrayList(first3,"联通") );
		headTitles.add( Lists.newArrayList(first3,"电信") );
		headTitles.add( Lists.newArrayList(first3,"拓展业务") );

		headTitles.add( Lists.newArrayList(first4,"移动") );
		headTitles.add( Lists.newArrayList(first4,"联通") );
		headTitles.add( Lists.newArrayList(first4,"电信") );

		headTitles.add( Lists.newArrayList(first5,"总计") );
		headTitles.add( Lists.newArrayList(first5,"移动") );
		headTitles.add( Lists.newArrayList(first5,"联通") );
		headTitles.add( Lists.newArrayList(first5,"电信") );
		headTitles.add( Lists.newArrayList(first5,"拓展业务") );

		headTitles.add( Lists.newArrayList(first6,"移动") );
		headTitles.add( Lists.newArrayList(first6,"联通") );
		headTitles.add( Lists.newArrayList(first6,"电信") );

		headTitles.add( Lists.newArrayList(first7,"上次抄表日期") );
		headTitles.add( Lists.newArrayList(first7,"本次抄表日期") );
		headTitles.add( Lists.newArrayList(first7,"上次表数") );
		headTitles.add( Lists.newArrayList(first7,"止码") );
		headTitles.add( Lists.newArrayList(first7,"用电量") );
		headTitles.add( Lists.newArrayList(first7,"金额") );

		headTitles.add( Lists.newArrayList(first8,"分摊系数账单金额") );

		headTitles.add( Lists.newArrayList(first9,"校验电费列") );

		headTitles.add( Lists.newArrayList(first10,"移动") );
		headTitles.add( Lists.newArrayList(first10,"联通") );
		headTitles.add( Lists.newArrayList(first10,"电信") );
		headTitles.add( Lists.newArrayList(first10,"拓展业务") );
		headTitles.add( Lists.newArrayList(first10,"5G移动") );
		headTitles.add( Lists.newArrayList(first10,"5G联通") );
		headTitles.add( Lists.newArrayList(first10,"5G电信") );
		headTitles.add( Lists.newArrayList(first10,"合计电费") );

		headTitles.add( Lists.newArrayList(first11,"移动") );
		headTitles.add( Lists.newArrayList(first11,"联通") );
		headTitles.add( Lists.newArrayList(first11,"电信") );
		headTitles.add( Lists.newArrayList(first11,"拓展业务") );
		headTitles.add( Lists.newArrayList(first11,"5G移动") );
		headTitles.add( Lists.newArrayList(first11,"5G联通") );
		headTitles.add( Lists.newArrayList(first11,"5G电信") );
		headTitles.add( Lists.newArrayList(first11,"合计总电量") );

		headTitles.add( Lists.newArrayList(first12,"移动") );
		headTitles.add( Lists.newArrayList(first12,"联通") );
		headTitles.add( Lists.newArrayList(first12,"电信") );
		headTitles.add( Lists.newArrayList(first12,"拓展业务") );

		headTitles.add( Lists.newArrayList(first13,"移动") );
		headTitles.add( Lists.newArrayList(first13,"联通") );
		headTitles.add( Lists.newArrayList(first13,"电信") );

		headTitles.add( Lists.newArrayList(first14,"移动") );
		headTitles.add( Lists.newArrayList(first14,"联通") );
		headTitles.add( Lists.newArrayList(first14,"电信") );
		headTitles.add( Lists.newArrayList(first14,"拓展业务") );

		headTitles.add( Lists.newArrayList(first15,"合计") );

		headTitles.add( Lists.newArrayList(first16,"移动税负因子") );
		headTitles.add( Lists.newArrayList(first16,"联通税负因子") );
		headTitles.add( Lists.newArrayList(first16,"电信税负因子") );
		headTitles.add( Lists.newArrayList(first16,"移动5G税负因子") );
		headTitles.add( Lists.newArrayList(first16,"联通5G税负因子") );
		headTitles.add( Lists.newArrayList(first16,"电信5G税负因子") );
		headTitles.add( Lists.newArrayList(first16,"税负因子总计") );
		headTitles.add( Lists.newArrayList(first16,"移动4G分摊") );
		headTitles.add( Lists.newArrayList(first16,"联通4G分摊") );
		headTitles.add( Lists.newArrayList(first16,"电信4G分摊") );
		headTitles.add( Lists.newArrayList(first16,"拓展能源") );
		headTitles.add( Lists.newArrayList(first16,"移动5G") );
		headTitles.add( Lists.newArrayList(first16,"联通5G") );
		headTitles.add( Lists.newArrayList(first16,"电信5G") );
		headTitles.add( Lists.newArrayList(first16,"最终分摊合计") );

		headTitles.add( Lists.newArrayList(first17,"一站多表") );

		headTitles.add( Lists.newArrayList(first18,"一表多站") );

		headTitles.add( Lists.newArrayList(first19,"备注") );

		headTitles.add( Lists.newArrayList(first20,"钉钉流程编号") );

		return headTitles;
	}

	private static List <List<Object>> contentData(){
		List<List<Object>> contentList = Lists.newArrayList();
		//这里一个List<Object>才代表一行数据，需要映射成每行数据填充，横向填充（把实体数据的字段设置成一个List<Object>）
		contentList.add( Lists.newArrayList("测试", "商品A","苹果") );
		contentList.add( Lists.newArrayList("测试", "商品B","橙子") );
		return contentList;
	}

	/**
	 * 导入转供电
	 */
	@PostMapping("importZgd")
	@ApiOperationSupport(order = 2)
	@ApiOperation(value = "导入转供电", notes = "传入excel")
	public R importZgd(MultipartFile file, String dfny) {
		String filename = file.getOriginalFilename();
		if (StringUtils.isEmpty(filename)) {
			throw new RuntimeException("请上传文件!");
		}
		if ((!StringUtils.endsWithIgnoreCase(filename, ".xls") && !StringUtils.endsWithIgnoreCase(filename, ".xlsx"))) {
			throw new RuntimeException("请上传正确的excel文件!");
		}
		InputStream inputStream;
		try {
			TzxxZgdImportListener importListener = new TzxxZgdImportListener(tzxxService);
			TzxxZgdImportListener.DFNY=dfny;
			inputStream = new BufferedInputStream(file.getInputStream());
			ExcelReader excelReader = EasyExcel.read(inputStream).build();
			ReadSheet readSheet0 = EasyExcel.readSheet(0).headRowNumber(2).head(TzxxZgdExcel.class).registerReadListener(importListener).build();
			excelReader.read(readSheet0);
			return R.success("操作成功");
		} catch (Exception e) {
			e.printStackTrace();
			return R.fail("数据格式错误，请核对后重新导入");
		}
	}
}
