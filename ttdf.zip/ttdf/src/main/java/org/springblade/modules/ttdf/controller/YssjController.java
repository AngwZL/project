/**
 * Copyright (c) 2018-2028, Chill Zhuang 庄骞 (smallchill@163.com).
 * <p>
 * Licensed under the GNU LESSER GENERAL PUBLIC LICENSE 3.0;
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * <p>
 * http://www.gnu.org/licenses/lgpl.html
 * <p>
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.springblade.modules.ttdf.controller;

import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.ExcelReader;
import com.alibaba.excel.exception.ExcelAnalysisException;
import com.alibaba.excel.exception.ExcelDataConvertException;
import com.alibaba.excel.metadata.CellData;
import com.alibaba.excel.read.builder.ExcelReaderBuilder;
import com.alibaba.excel.read.metadata.ReadSheet;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.AllArgsConstructor;
import org.springblade.core.boot.ctrl.BladeController;
import org.springblade.core.mp.support.Condition;
import org.springblade.core.mp.support.Query;
import org.springblade.core.tool.api.R;
import org.springblade.core.tool.utils.Func;
import org.springblade.modules.ttdf.entity.Yssj;
import org.springblade.modules.ttdf.excel.ClhsjExcel;
import org.springblade.modules.ttdf.excel.ClhsjImportListener;
import org.springblade.modules.ttdf.excel.YssjExcel;
import org.springblade.modules.ttdf.excel.YssjImportListener;
import org.springblade.modules.ttdf.service.IYssjService;
import org.springblade.modules.ttdf.vo.YssjVO;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 原始数据 控制器
 *
 * @author Blade
 * @since 2023-05-09
 */
@RestController
@AllArgsConstructor
@RequestMapping("/ttdf/yssj")
@Api(value = "原始数据", tags = "原始数据接口")
public class YssjController extends BladeController {

	private IYssjService yssjService;

	/**
	 * 自定义分页 原始数据列表接口
	 */
	@GetMapping("/page")
	@ApiOperationSupport(order = 1)
	@ApiOperation(value = "原始数据列表", notes = "传入yssj")
	public R<IPage<YssjVO>> page(YssjVO yssj, Query query) {
		IPage<YssjVO> pages = yssjService.selectYssjPage(Condition.getPage(query), yssj);
		return R.data(pages);
	}

	/**
	 * 自定义分页 换表记录
	 */
	@GetMapping("/pageHB")
	@ApiOperationSupport(order = 1)
	@ApiOperation(value = "换表记录列表", notes = "传入yssj")
	public R<IPage<YssjVO>> pageHB(YssjVO yssj, Query query) {
		IPage<YssjVO> pages = yssjService.selectYssjHBPage(Condition.getPage(query), yssj);
		return R.data(pages);
	}

	/**
	 * 导入原始数据
	 */
	@PostMapping("importYssj")
	@ApiOperationSupport(order = 2)
	@ApiOperation(value = "导入原始数据", notes = "传入excel")
	public R importYssj(MultipartFile file, String qy, String dfny) {
		String filename = file.getOriginalFilename();
		if (StringUtils.isEmpty(filename)) {
			throw new RuntimeException("请上传文件!");
		}
		if ((!StringUtils.endsWithIgnoreCase(filename, ".xls") && !StringUtils.endsWithIgnoreCase(filename, ".xlsx"))) {
			throw new RuntimeException("请上传正确的excel文件!");
		}
		InputStream inputStream;
		try {
			//大冶、现业的excel是一种格式，阳新是另外一种格式
			if(qy.equals("大冶") || qy.equals("现业")){
				YssjImportListener importListener = new YssjImportListener(yssjService);
				YssjImportListener.DFNY=dfny;
				YssjImportListener.QY=qy;
				inputStream = new BufferedInputStream(file.getInputStream());
				ExcelReader excelReader = EasyExcel.read(inputStream).build();
				ReadSheet readSheet0 = EasyExcel.readSheet(0).headRowNumber(2).head(YssjExcel.class).registerReadListener(importListener).build();
				excelReader.read(readSheet0);
			}else{
				YssjImportListener importListener = new YssjImportListener(yssjService);
				YssjImportListener.DFNY=dfny;
				YssjImportListener.QY=qy;
				inputStream = new BufferedInputStream(file.getInputStream());
				ExcelReader excelReader = EasyExcel.read(inputStream).build();
				ReadSheet readSheet0 = EasyExcel.readSheet(0).headRowNumber(2).head(YssjExcel.class).registerReadListener(importListener).build();
				ReadSheet readSheet1 = EasyExcel.readSheet(1).headRowNumber(2).head(YssjExcel.class).registerReadListener(importListener).build();
				ReadSheet readSheet2 = EasyExcel.readSheet(2).headRowNumber(2).head(YssjExcel.class).registerReadListener(importListener).build();
				excelReader.read(readSheet0,readSheet1,readSheet2);
			}
			return R.success("操作成功");
		} catch (ExcelAnalysisException e){
			//提示哪个单元格数据有异常
			e.printStackTrace();
			ExcelDataConvertException cause = (ExcelDataConvertException) e.getCause();
			Integer rowIndex = cause.getRowIndex();
			Integer columnIndex = cause.getColumnIndex();
			CellData cellData = cause.getCellData();
			return R.fail("第"+(rowIndex+1)+"行"+"第"+(columnIndex+1)+"列"+"数据："+cellData.getStringValue()+" 格式错误，请核对后重新导入");
		} catch (Exception e) {
			return R.fail("数据格式错误，请核对后重新导入");
		}


	}

	/**
	 * 删除 原始数据
	 */
	@PostMapping("/remove")
	@ApiOperationSupport(order = 3)
	@ApiOperation(value = "逻辑删除", notes = "传入ids")
	public R remove(@ApiParam(value = "主键集合", required = true) @RequestParam String ids) {
		return R.status(yssjService.removeBatchByIds(Func.toLongList(ids)));
	}

	/**
	 * 数据处理
	 */
	@PostMapping("/sjcl")
	@ApiOperationSupport(order = 4)
	@ApiOperation(value = "数据处理")
	public R<List<Yssj>> sjcl(String qy, String dfny) {
		List<Yssj> listHB = yssjService.listHB(new HashMap<>());
		return R.data(listHB);
	}



	/**
	 * 订单搜索框模糊匹配
	 */
	@GetMapping("/queryYhbh")
	public R<List<Map>> queryYhbh(@RequestParam Map<String, Object> params) {
		List<Map> list = yssjService.queryYhbh(params);
		return R.data(list);
	}

	@GetMapping("/queryYys")
	public R<List<Map>> queryYys(@RequestParam Map<String, Object> params) {
		List<Map> list = yssjService.queryYys(params);
		return R.data(list);
	}

	@GetMapping("/queryYddz")
	public R<List<Map>> queryYddz(@RequestParam Map<String, Object> params) {
		List<Map> list = yssjService.queryYddz(params);
		return R.data(list);
	}

	@GetMapping("/queryDbbh")
	public R<List<Map>> queryDbbh(@RequestParam Map<String, Object> params) {
		List<Map> list = yssjService.queryDbbh(params);
		return R.data(list);
	}
}
