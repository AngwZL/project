/**
 * Copyright (c) 2018-2028, Chill Zhuang 庄骞 (smallchill@163.com).
 * <p>
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * <p>
 * http://www.apache.org/licenses/LICENSE-2.0
 * <p>
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.springblade.modules.ttdf.service;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.extension.service.IService;
import org.springblade.modules.system.entity.User;
import org.springblade.modules.system.excel.UserExcel;
import org.springblade.modules.ttdf.entity.Tzxx;
import org.springblade.modules.ttdf.entity.Yssj;
import org.springblade.modules.ttdf.excel.TzftxxExcel;
import org.springblade.modules.ttdf.excel.TzxxExcel;
import org.springblade.modules.ttdf.excel.TzxxExcelYD;
import org.springblade.modules.ttdf.excel.TzxxZgdExcel;
import org.springblade.modules.ttdf.vo.TzxxVO;
import org.springblade.core.mp.base.BaseService;
import com.baomidou.mybatisplus.core.metadata.IPage;

import java.util.List;
import java.util.Map;

/**
 * 台账信息 服务类
 *
 * @author Blade
 * @since 2023-05-19
 */
public interface ITzxxService extends IService<Tzxx> {

	/**
	 * 自定义分页
	 *
	 * @param page
	 * @param tzxx
	 * @return
	 */
	IPage<TzxxVO> selectTzxxPage(IPage<TzxxVO> page, TzxxVO tzxx);
	List<Tzxx> sctzList1(Map<String, Object> map);
	List<Tzxx> sctzList2(Map<String, Object> map);
	List<Map> tzxxtj(Map<String, Object> map);
	List<Map> tzxxtjByQy(Map<String, Object> map);

	List<TzxxExcel> exportTzxx(Tzxx tzxx);

	List<TzxxExcel> exportQrd(Tzxx tzxx);

	List<TzxxExcelYD> exportQrdYD(Tzxx tzxx);

	List<Map> mapList(Map<String, Object> map);

	void importTzxx(List<TzxxZgdExcel> data);
}
