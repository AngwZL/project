/**
 * Copyright (c) 2018-2028, Chill Zhuang 庄骞 (smallchill@163.com).
 * <p>
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * <p>
 * http://www.apache.org/licenses/LICENSE-2.0
 * <p>
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.springblade.modules.ttdf.vo;

import io.swagger.annotations.ApiModelProperty;
import org.springblade.modules.ttdf.entity.Dzpj;
import lombok.Data;
import lombok.EqualsAndHashCode;
import io.swagger.annotations.ApiModel;

/**
 * 电子票据视图实体类
 *
 * @author Blade
 * @since 2023-05-30
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ApiModel(value = "DzpjVO对象", description = "电子票据")
public class DzpjVO extends Dzpj {
	private static final long serialVersionUID = 1L;

	/**
	 * 汇总清单-直供电电量
	 */
	@ApiModelProperty(value = "电量")
	private Double dlZJ;
	/**
	 * 汇总清单-直供电金额
	 */
	@ApiModelProperty(value = "金额")
	private Double jineZJ;
	/**
	 * 汇总清单-直供电电量
	 */
	@ApiModelProperty(value = "电量")
	private Double dlZhiGong;
	/**
	 * 汇总清单-直供电金额
	 */
	@ApiModelProperty(value = "金额")
	private Double jineZhiGong;

	/**
	 * 汇总清单-转供电电量
	 */
	@ApiModelProperty(value = "电量")
	private Double dlZhuanGong;
	/**
	 * 汇总清单-转供电金额
	 */
	@ApiModelProperty(value = "金额")
	private Double jineZhuanGong;
}
