/**
 * Copyright (c) 2018-2028, Chill Zhuang 庄骞 (smallchill@163.com).
 * <p>
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * <p>
 * http://www.apache.org/licenses/LICENSE-2.0
 * <p>
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.springblade.modules.ttdf.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.NullSerializer;
import org.springblade.core.mp.base.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 异常数据实体类
 *
 * @author Blade
 * @since 2023-05-09
 */
@Data
@TableName("ttdf_ycsj")
@ApiModel(value = "Ycsj对象", description = "异常数据")
public class Ycsj {

    private static final long serialVersionUID = 1L;

  @TableId(value = "id", type = IdType.AUTO)
  private Integer id;
    /**
	 * 异常类型：
	 * 1、分摊异常
	 * 2、未缴纳电费异常
	 * 3、未起租已缴费异常
	 * 4、电量异常
     */
    @ApiModelProperty(value = "异常类型")
    private Integer type;
    /**
     * 业务数据id
     */
    @ApiModelProperty(value = "业务数据id")
    private String ywId;
    /**
     * 起码
     */
    @ApiModelProperty(value = "状态")
	@JsonSerialize(nullsUsing = NullSerializer.class)
    private Integer status;
    /**
     * 止码
     */
    @ApiModelProperty(value = "数据时间")
	@JsonSerialize(nullsUsing = NullSerializer.class)
    private String sj;

	/**
	 * 区域
	 */
	@ApiModelProperty(value = "区域")
	private String qy;

}
