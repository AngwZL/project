/**
 * Copyright (c) 2018-2028, Chill Zhuang 庄骞 (smallchill@163.com).
 * <p>
 * Licensed under the GNU LESSER GENERAL PUBLIC LICENSE 3.0;
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * <p>
 * http://www.gnu.org/licenses/lgpl.html
 * <p>
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.springblade.modules.ttdf.controller;

import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.ExcelReader;
import com.alibaba.excel.read.builder.ExcelReaderBuilder;
import com.alibaba.excel.read.metadata.ReadSheet;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import lombok.AllArgsConstructor;
import javax.validation.Valid;

import org.springblade.core.mp.support.Condition;
import org.springblade.core.mp.support.Query;
import org.springblade.core.tool.api.R;
import org.springblade.core.tool.utils.Func;
import org.springblade.modules.ttdf.entity.Tzxx;
import org.springblade.modules.ttdf.excel.*;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.RequestParam;
import com.baomidou.mybatisplus.core.metadata.IPage;
import org.springblade.modules.ttdf.entity.Qzxx;
import org.springblade.modules.ttdf.vo.QzxxVO;
import org.springblade.modules.ttdf.service.IQzxxService;
import org.springblade.core.boot.ctrl.BladeController;
import org.springframework.web.multipart.MultipartFile;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Map;

/**
 * 起租信息表 控制器
 *
 * @author Blade
 * @since 2023-05-23
 */
@RestController
@AllArgsConstructor
@RequestMapping("/ttdf/qzxx")
@Api(value = "起租信息表", tags = "起租信息表接口")
public class QzxxController extends BladeController {

	private IQzxxService qzxxService;

	/**
	 * 详情
	 */
	@GetMapping("/detail")
	@ApiOperationSupport(order = 1)
	@ApiOperation(value = "详情", notes = "传入qzxx")
	public R<Qzxx> detail(Qzxx qzxx) {
		Qzxx detail = qzxxService.getOne(Condition.getQueryWrapper(qzxx));
		return R.data(detail);
	}

	/**
	 * 数量
	 */
	@GetMapping("/count")
	@ApiOperationSupport(order = 1)
	@ApiOperation(value = "详情", notes = "传入tzxx")
	public R<Long> count(String dfny) {
		Qzxx qzxx = new Qzxx();
		qzxx.setSj(dfny);
		long count = qzxxService.count(Condition.getQueryWrapper(qzxx));
		return R.data(count);
	}

	/**
	 * 分页 起租信息表
	 */
	@GetMapping("/list")
	@ApiOperationSupport(order = 2)
	@ApiOperation(value = "分页", notes = "传入qzxx")
	public R<IPage<Qzxx>> list(Qzxx qzxx, Query query) {
		IPage<Qzxx> pages = qzxxService.page(Condition.getPage(query), Condition.getQueryWrapper(qzxx));
		return R.data(pages);
	}

	/**
	 * 自定义分页 起租信息表
	 */
	@GetMapping("/page")
	@ApiOperationSupport(order = 3)
	@ApiOperation(value = "分页", notes = "传入qzxx")
	public R<IPage<QzxxVO>> page(QzxxVO qzxx, Query query) {
		IPage<QzxxVO> pages = qzxxService.selectQzxxPage(Condition.getPage(query), qzxx);
		return R.data(pages);
	}

	/**
	 * 新增 起租信息表
	 */
	@PostMapping("/save")
	@ApiOperationSupport(order = 4)
	@ApiOperation(value = "新增", notes = "传入qzxx")
	public R save(@Valid @RequestBody Qzxx qzxx) {
		return R.status(qzxxService.save(qzxx));
	}

	/**
	 * 修改 起租信息表
	 */
	@PostMapping("/update")
	@ApiOperationSupport(order = 5)
	@ApiOperation(value = "修改", notes = "传入qzxx")
	public R update(@Valid @RequestBody Qzxx qzxx) {
		return R.status(qzxxService.updateById(qzxx));
	}

	/**
	 * 新增或修改 起租信息表
	 */
	@PostMapping("/submit")
	@ApiOperationSupport(order = 6)
	@ApiOperation(value = "新增或修改", notes = "传入qzxx")
	public R submit(@Valid @RequestBody Qzxx qzxx) {
		return R.status(qzxxService.saveOrUpdate(qzxx));
	}


	/**
	 * 导入起租信息
	 */
	@PostMapping("importQzxx")
	@ApiOperationSupport(order = 2)
	@ApiOperation(value = "导入起租信息", notes = "传入excel")
	public R importQzxx(MultipartFile file, String qy, String dfny, String fg) {
		if("1".equals(fg)){
			Qzxx qzxx = new Qzxx();
			qzxx.setSj(dfny);
			qzxxService.remove(Condition.getQueryWrapper(qzxx));
		}
		String filename = file.getOriginalFilename();
		if (StringUtils.isEmpty(filename)) {
			throw new RuntimeException("请上传文件!");
		}
		if ((!StringUtils.endsWithIgnoreCase(filename, ".xls") && !StringUtils.endsWithIgnoreCase(filename, ".xlsx"))) {
			throw new RuntimeException("请上传正确的excel文件!");
		}
		InputStream inputStream;
		try {
			inputStream = new BufferedInputStream(file.getInputStream());
			ExcelReader excelReader = EasyExcel.read(inputStream).build();
			QzxxImportListener importListener0 = new QzxxImportListener(qzxxService);
			QzxxImportListener.DFNY=dfny;
			ReadSheet readSheet0 = EasyExcel.readSheet(0).headRowNumber(4).head(QzxxExcel.class).registerReadListener(importListener0).build();

			QzxxImportListener1 importListener1 = new QzxxImportListener1(qzxxService);
			QzxxImportListener1.DFNY=dfny;
			ReadSheet readSheet1 = EasyExcel.readSheet(1).headRowNumber(4).head(QzxxExcel1.class).registerReadListener(importListener1).build();

			QzxxImportListener2 importListener2 = new QzxxImportListener2(qzxxService);
			QzxxImportListener2.DFNY=dfny;
			ReadSheet readSheet2 = EasyExcel.readSheet(2).headRowNumber(4).head(QzxxExcel2.class).registerReadListener(importListener2).build();

			QzxxImportListener3 importListener3 = new QzxxImportListener3(qzxxService);
			QzxxImportListener3.DFNY=dfny;
			ReadSheet readSheet3 = EasyExcel.readSheet(3).headRowNumber(4).head(QzxxExcel3.class).registerReadListener(importListener3).build();

			QzxxImportListener4 importListener4 = new QzxxImportListener4(qzxxService);
			QzxxImportListener4.DFNY=dfny;
			ReadSheet readSheet4 = EasyExcel.readSheet(4).headRowNumber(4).head(QzxxExcel4.class).registerReadListener(importListener4).build();

			excelReader.read(readSheet0, readSheet1, readSheet2, readSheet3, readSheet4);

		} catch (IOException e) {
			e.printStackTrace();
		}
		return R.success("操作成功");

	}



	/**
	 * 未缴纳电费
	 */
	@GetMapping("/wjndf")
	@ApiOperationSupport(order = 3)
	@ApiOperation(value = "分页", notes = "传入qzxx")
	public R<IPage<Map>> wjndf(QzxxVO qzxx, Query query) {
		IPage<Map> pages = qzxxService.wjndf(Condition.getPage(query), qzxx);
		return R.data(pages);
	}

	/**
	 * 未起租已缴费
	 */
	@GetMapping("/wqzyjf")
	@ApiOperationSupport(order = 3)
	@ApiOperation(value = "分页", notes = "传入qzxx")
	public R<IPage<Map>> wqzyjf(QzxxVO qzxx, Query query) {
		IPage<Map> pages = qzxxService.wqzyjf(Condition.getPage(query), qzxx);
		return R.data(pages);
	}


	/**
	 * 起租信息搜索框模糊匹配
	 */
	@GetMapping("/queryZzbm")
	public R<List<Map>> queryZzbm(@RequestParam Map<String, Object> params) {
		List<Map> list = qzxxService.queryZzbm(params);
		return R.data(list);
	}

	@GetMapping("/queryZhm")
	public R<List<Map>> queryZhm(@RequestParam Map<String, Object> params) {
		List<Map> list = qzxxService.queryZhm(params);
		return R.data(list);
	}
}
