/**
 * Copyright (c) 2018-2028, Chill Zhuang 庄骞 (smallchill@163.com).
 * <p>
 * Licensed under the GNU LESSER GENERAL PUBLIC LICENSE 3.0;
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * <p>
 * http://www.gnu.org/licenses/lgpl.html
 * <p>
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.springblade.modules.ttdf.controller;

import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.ExcelReader;
import com.alibaba.excel.exception.ExcelAnalysisException;
import com.alibaba.excel.exception.ExcelDataConvertException;
import com.alibaba.excel.metadata.CellData;
import com.alibaba.excel.read.builder.ExcelReaderBuilder;
import com.alibaba.excel.read.metadata.ReadSheet;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import lombok.AllArgsConstructor;
import javax.validation.Valid;

import org.springblade.core.mp.support.Condition;
import org.springblade.core.mp.support.Query;
import org.springblade.core.tool.api.R;
import org.springblade.core.tool.utils.Func;
import org.springblade.modules.ttdf.entity.Tzftxx;
import org.springblade.modules.ttdf.entity.Ycsj;
import org.springblade.modules.ttdf.excel.ClhsjExcel;
import org.springblade.modules.ttdf.excel.ClhsjImportListener;
import org.springblade.modules.ttdf.excel.QzxxExcel;
import org.springblade.modules.ttdf.excel.QzxxImportListener;
import org.springblade.modules.ttdf.vo.YssjVO;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.RequestParam;
import com.baomidou.mybatisplus.core.metadata.IPage;
import org.springblade.modules.ttdf.entity.Clhsj;
import org.springblade.modules.ttdf.vo.ClhsjVO;
import org.springblade.modules.ttdf.service.IClhsjService;
import org.springblade.core.boot.ctrl.BladeController;
import org.springframework.web.multipart.MultipartFile;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 处理后数据 控制器
 *
 * @author Blade
 * @since 2023-05-09
 */
@RestController
@AllArgsConstructor
@RequestMapping("/ttdf/clhsj")
@Api(value = "处理后数据", tags = "处理后数据接口")
public class ClhsjController extends BladeController {

	private IClhsjService clhsjService;

	/**
	 * 自定义分页 原始数据列表接口
	 */
	@GetMapping("/page")
	@ApiOperationSupport(order = 1)
	@ApiOperation(value = "处理后数据列表", notes = "传入clhsj")
	public R<IPage<ClhsjVO>> page(ClhsjVO clhsj, Query query) {
		IPage<ClhsjVO> pages = clhsjService.selectClhsjPage(Condition.getPage(query), clhsj);
		return R.data(pages);
	}

	/**
	 * 处理后数据修改
	 */
	@PostMapping("/update")
	@ApiOperationSupport(order = 2)
	@ApiOperation(value = "修改", notes = "传入Tzftxx")
	public R update(@Valid @RequestBody Clhsj clhsj) {
		return R.status(clhsjService.updateById(clhsj));
	}

	/**
	 * 删除 处理后数据
	 */
	@PostMapping("/remove")
	@ApiOperationSupport(order = 3)
	@ApiOperation(value = "删除", notes = "传入ids")
	public R remove(@ApiParam(value = "主键集合", required = true) @RequestParam String ids) {
		return R.status(clhsjService.removeBatchByIds(Func.toLongList(ids)));
	}

	/**
	 * 详情
	 */
	@GetMapping("/detail/{id}")
	@ApiOperationSupport(order = 1)
	@ApiOperation(value = "详情", notes = "传入ycsj")
	public Clhsj detail(@PathVariable("id") Integer id) {
		Clhsj detail = clhsjService.findById(id);
		return  detail;
	}

	/**
	 * 导入汇总清单
	 */
	@PostMapping("importClhsj")
	@ApiOperationSupport(order = 2)
	@ApiOperation(value = "导入汇总清单", notes = "传入excel")
	public R importClhsj(MultipartFile file, String dfny) {
		String filename = file.getOriginalFilename();
		if (StringUtils.isEmpty(filename)) {
			throw new RuntimeException("请上传文件!");
		}
		if ((!StringUtils.endsWithIgnoreCase(filename, ".xls") && !StringUtils.endsWithIgnoreCase(filename, ".xlsx"))) {
			throw new RuntimeException("请上传正确的excel文件!");
		}
		InputStream inputStream;
		try {
			ClhsjImportListener importListener = new ClhsjImportListener(clhsjService);
			ClhsjImportListener.DFNY=dfny;
			inputStream = new BufferedInputStream(file.getInputStream());
			ExcelReader excelReader = EasyExcel.read(inputStream).build();
			ReadSheet readSheet0 = EasyExcel.readSheet(0).headRowNumber(2).head(ClhsjExcel.class).registerReadListener(importListener).build();
			excelReader.read(readSheet0);
			return R.success("操作成功");
		}catch (ExcelAnalysisException e){
			//提示哪个单元格数据有异常
			e.printStackTrace();
			ExcelDataConvertException cause = (ExcelDataConvertException) e.getCause();
			Integer rowIndex = cause.getRowIndex();
			Integer columnIndex = cause.getColumnIndex();
			CellData cellData = cause.getCellData();
			return R.fail("第"+(rowIndex+1)+"行"+"第"+(columnIndex+1)+"列"+"数据："+cellData.getStringValue()+" 格式错误，请核对后重新导入");
		} catch (Exception e) {
			e.printStackTrace();
			return R.fail("数据格式错误，请核对后重新导入");
		}
	}


	/**
	 * 汇总清单统计
	 */
	@GetMapping("/hzqdtj")
	public R<Map> hzqdtj(@RequestParam Map<String, Object> params) {
		Map<String, Object> result = new HashMap<>();
		List<Map> list = clhsjService.hzqdtj(params);
		double bcdl = 0;
		double jine = 0;
		for(Map m : list){
			if(m.get("qy")!=null && m.get("qy").equals("现业")){
				result.put("xy_dl",String.format("%.2f",m.get("dl")));
				result.put("xy_jine",String.format("%.2f",m.get("jine")));
				bcdl += Double.parseDouble(m.get("dl").toString());
				jine += Double.parseDouble(m.get("jine").toString());
			}
			if(m.get("qy")!=null && m.get("qy").equals("大冶")){
				result.put("dy_dl",String.format("%.2f",m.get("dl")));
				result.put("dy_jine",String.format("%.2f",m.get("jine")));
				bcdl += Double.parseDouble(m.get("dl").toString());
				jine += Double.parseDouble(m.get("jine").toString());
			}
			if(m.get("qy")!=null && m.get("qy").equals("阳新")){
				result.put("yx_dl",String.format("%.2f",m.get("dl")));
				result.put("yx_jine",String.format("%.2f",m.get("jine")));
				bcdl += Double.parseDouble(m.get("dl").toString());
				jine += Double.parseDouble(m.get("jine").toString());
			}
		}
		result.put("zj_dl",String.format("%.2f",bcdl));
		result.put("zj_jine",String.format("%.2f",jine));
		return R.data(result);
	}
}
