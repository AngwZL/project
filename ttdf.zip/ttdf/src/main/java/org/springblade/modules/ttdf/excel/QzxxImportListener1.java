package org.springblade.modules.ttdf.excel;

import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.event.AnalysisEventListener;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.RequiredArgsConstructor;
import org.springblade.core.tool.utils.BeanUtil;
import org.springblade.modules.ttdf.entity.Qzxx;
import org.springblade.modules.ttdf.service.IQzxxService;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * UserImportListener
 *
 * @author Chill
 */
@Data
@RequiredArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class QzxxImportListener1 extends AnalysisEventListener<QzxxExcel1> {

	public static String DFNY="";
	/**
	 * 默认每隔3000条存储数据库
	 */
	private int batchCount = 50000;
	/**
	 * 缓存的数据列表
	 */
	private List<Qzxx> list = new ArrayList<>();
	/**
	 * 用户service
	 */
	private final IQzxxService qzxxService;

	@Override
	public void invoke(QzxxExcel1 data, AnalysisContext context) {
		data.setSj(DFNY);
		if(data.getQy()!=null && !data.getQy().equals("") && data.getQy().indexOf("阳新")>-1){
			data.setQy("阳新");
		}else if(data.getQy()!=null && !data.getQy().equals("") && data.getQy().indexOf("大冶")>-1){
			data.setQy("大冶");
		}else if(data.getQy()!=null && !data.getQy().equals("")){
			data.setQy("现业");
		}
		list.add(Objects.requireNonNull(BeanUtil.copy(data, Qzxx.class)));
		// 达到BATCH_COUNT，则调用importer方法入库，防止数据几万条数据在内存，容易OOM
		if (list.size() >= batchCount) {
			// 调用importer方法
			qzxxService.importQzxx(list);
			// 存储完成清理list
			list.clear();
		}
	}

	@Override
	public void doAfterAllAnalysed(AnalysisContext analysisContext) {
		// 调用importer方法
		qzxxService.importQzxx(list);
		// 存储完成清理list
		list.clear();
	}

}
