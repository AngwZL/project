/**
 * Copyright (c) 2018-2028, Chill Zhuang 庄骞 (smallchill@163.com).
 * <p>
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * <p>
 * http://www.apache.org/licenses/LICENSE-2.0
 * <p>
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.springblade.modules.ttdf.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.NullSerializer;
import org.springblade.core.mp.base.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 台账分摊信息实体类
 *
 * @author Blade
 * @since 2023-05-09
 */
@Data
@TableName("ttdf_tzftxx")
@ApiModel(value = "Tzftxx对象", description = "台账分摊信息")
public class Tzftxx{

    private static final long serialVersionUID = 1L;

	  @TableId(value = "id", type = IdType.AUTO)
	  private Integer id;
	/**
	 * 业务序号
	 */
	@ApiModelProperty(value = "业务序号")
	private String ywXh;
    /**
     * 用户编号
     */
    @ApiModelProperty(value = "用户编号")
    private String yhbh;
    /**
     * 电表编号
     */
    @ApiModelProperty(value = "电表编号")
    private String dbbh;
    /**
     * 区县
     */
    @ApiModelProperty(value = "区县")
    private String qy;
    /**
     * 月份
     */
    @ApiModelProperty(value = "月份")
    private String yf;
    /**
     * 站点编码
     */
    @ApiModelProperty(value = "站点编码")
    private String zdbm;
    /**
     * 站名
     */
    @ApiModelProperty(value = "站名")
    private String zhm;
    /**
     * 分摊系数
     */
    @ApiModelProperty(value = "分摊系数")
    private String ftxs;
    /**
     * 是否有拓展业务
     */
    @ApiModelProperty(value = "是否有拓展业务")
    private String sfytzyw;
    /**
     * 运营商
     */
    @ApiModelProperty(value = "运营商")
    private String yys;
    /**
     * 供电方式
     */
    @ApiModelProperty(value = "供电方式")
    private String gdfs;
    /**
     * 基础数据总计
     */
    @ApiModelProperty(value = "基础数据总计")
    private Double jczj;
    /**
     * 移动4G
     */
    @ApiModelProperty(value = "移动4G")
	@JsonSerialize(nullsUsing = NullSerializer.class)
    private Double yd4g;
    /**
     * 联通4G
     */
    @ApiModelProperty(value = "联通4G")
	@JsonSerialize(nullsUsing = NullSerializer.class)
    private Double lt4g;
    /**
     * 电信4G
     */
    @ApiModelProperty(value = "电信4G")
	@JsonSerialize(nullsUsing = NullSerializer.class)
    private Double dx4g;
    /**
     * 拓展业务基数
     */
    @ApiModelProperty(value = "拓展业务基数")
    private Double tzywjs;
    /**
     * 移动5G
     */
    @ApiModelProperty(value = "移动5G")
	@JsonSerialize(nullsUsing = NullSerializer.class)
    private Double yd5g;
    /**
     * 联通5G
     */
    @ApiModelProperty(value = "联通5G")
	@JsonSerialize(nullsUsing = NullSerializer.class)
    private Double lt5g;
    /**
     * 电信5G
     */
    @ApiModelProperty(value = "电信5G")
	@JsonSerialize(nullsUsing = NullSerializer.class)
    private Double dx5g;
    /**
     * 总计分摊比例
     */
    @ApiModelProperty(value = "总计分摊比例")
    private String zjftbl;
    /**
     * 移动分摊比例4G
     */
    @ApiModelProperty(value = "移动分摊比例4G")
    private String ydftbl4g;
    /**
     * 联通分摊比例4G
     */
    @ApiModelProperty(value = "联通分摊比例4G")
    private String ltftbl4g;
    /**
     * 电信分摊比例4G
     */
    @ApiModelProperty(value = "电信分摊比例4G")
    private String dxftbl4g;
    /**
     * 拓展业务比例
     */
    @ApiModelProperty(value = "拓展业务比例")
    private String tzywbl;
    /**
     * 移动分摊比例5G
     */
    @ApiModelProperty(value = "移动分摊比例5G")
    private String ydftbl5g;
    /**
     * 联通分摊比例5G
     */
    @ApiModelProperty(value = "联通分摊比例5G")
    private String ltftbl5g;
    /**
     * 电信分摊比例5G
     */
    @ApiModelProperty(value = "电信分摊比例5G")
    private String dxftbl5g;
    /**
     * 一站多表
     */
    @ApiModelProperty(value = "一站多表")
    private String yzdb;
    /**
     * 一表多站
     */
    @ApiModelProperty(value = "一表多站")
    private String ybdz;
    /**
     * 备注(一表一站)
     */
    @ApiModelProperty(value = "备注(一表一站)")
    private String bzybyz;
    /**
     * 钉钉流程编号
     */
    @ApiModelProperty(value = "钉钉流程编号")
    private String ddlcbh;
    /**
     * 网格负责人
     */
    @ApiModelProperty(value = "网格负责人")
    private String wgfzr;


}
