package org.springblade.modules.ttdf.excel;

import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.event.AnalysisEventListener;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.RequiredArgsConstructor;
import org.springblade.modules.ttdf.service.IClhsjService;
import org.springblade.modules.ttdf.service.ITzftxxService;

import java.util.ArrayList;
import java.util.List;

/**
 * UserImportListener
 *
 * @author Chill
 */
@Data
@RequiredArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class TzftxxImportListener extends AnalysisEventListener<TzftxxExcel> {

	public static String DFNY="";
	/**
	 * 默认每隔3000条存储数据库
	 */
	private int batchCount = 10000;
	/**
	 * 缓存的数据列表
	 */
	private List<TzftxxExcel> list = new ArrayList<>();
	/**
	 * 用户service
	 */
	private final ITzftxxService tzftxxService;

	@Override
	public void invoke(TzftxxExcel data, AnalysisContext context) {
		list.add(data);
		// 达到BATCH_COUNT，则调用importer方法入库，防止数据几万条数据在内存，容易OOM
		if (list.size() >= batchCount) {
			// 调用importer方法
			tzftxxService.importTzftxx(list);
			// 存储完成清理list
			list.clear();
		}
	}

	@Override
	public void doAfterAllAnalysed(AnalysisContext analysisContext) {
		// 调用importer方法
		tzftxxService.importTzftxx(list);
		// 存储完成清理list
		list.clear();
	}

}
