/**
 * Copyright (c) 2018-2028, Chill Zhuang 庄骞 (smallchill@163.com).
 * <p>
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * <p>
 * http://www.apache.org/licenses/LICENSE-2.0
 * <p>
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.springblade.modules.ttdf.excel;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import lombok.Data;

/**
 * 台账信息实体类
 *
 * @author Blade
 * @since 2023-05-19
 */
@Data
@TableName("ttdf_yldf")
@ApiModel(value = "ttdf_yldf对象", description = "遗留电费-确认单信息")
public class YldfExcel {

    private static final long serialVersionUID = 1L;

	/**
	 * 区域
	 */
	@ExcelProperty(value = "区县")
	private String qy;
	/**
	 * 月份
	 */
	@ExcelProperty(value = "起始月份")
	private String startYf;

	/**
	 * 月份
	 */
	@ExcelProperty(value = "截止月份")
	private String endYf;

	/**
	 * 站点编码
	 */
	@ExcelProperty(value = "站点编码")
	private String zdbm;
	/**
	 * 站名
	 */
	@ExcelProperty(value = "站名")
	private String zhm;

    /**
     * 运营商
     */
    @ExcelProperty(value = "运营商")
    private String yys;

	/**
     * 类型
     */
    @ExcelProperty(value = "类型")
    private Integer type;

    /**
     * 确认金额
     */
    @ExcelProperty(value = "确认金额")
    private String qrje;

	/**
	 * 税负因子_联通4G分摊
	 */
	@ExcelProperty(value = "联通4G分摊")
	private String sfyzLt4gFt;

	/**
	 * 税负因子_电信4G分摊
	 */
	@ExcelProperty(value = "电信4G分摊")
	private String sfyzDx4gFt;

	/**
	 * 税负因子_电信5G分摊
	 */
	@ExcelProperty(value = "电信5G")
	private String sfyzDx5gFt;

	/**
	 * 月份
	 */
	@ExcelProperty(value = "月份")
	private String yf;
}
