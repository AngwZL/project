/**
 * Copyright (c) 2018-2028, Chill Zhuang 庄骞 (smallchill@163.com).
 * <p>
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * <p>
 * http://www.apache.org/licenses/LICENSE-2.0
 * <p>
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.springblade.modules.ttdf.service.impl;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springblade.core.tool.utils.BeanUtil;
import org.springblade.core.tool.utils.StringUtil;
import org.springblade.modules.system.entity.User;
import org.springblade.modules.system.excel.UserExcel;
import org.springblade.modules.ttdf.entity.Tzftxx;
import org.springblade.modules.ttdf.entity.Tzxx;
import org.springblade.modules.ttdf.entity.Yssj;
import org.springblade.modules.ttdf.excel.*;
import org.springblade.modules.ttdf.vo.TzxxVO;
import org.springblade.modules.ttdf.mapper.TzxxMapper;
import org.springblade.modules.ttdf.service.ITzxxService;
import org.springblade.core.mp.base.BaseServiceImpl;
import org.springframework.stereotype.Service;
import com.baomidou.mybatisplus.core.metadata.IPage;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * 台账信息 服务实现类
 *
 * @author Blade
 * @since 2023-05-19
 */
@Service
public class TzxxServiceImpl extends ServiceImpl<TzxxMapper, Tzxx> implements ITzxxService {

	@Override
	public IPage<TzxxVO> selectTzxxPage(IPage<TzxxVO> page, TzxxVO tzxx) {
		return page.setRecords(baseMapper.selectTzxxPage(page, tzxx));
	}
	@Override
	public List<Tzxx> sctzList1(Map<String, Object> map) {
		return baseMapper.sctzList1(map);
	}
	@Override
	public List<Tzxx> sctzList2(Map<String, Object> map) {
		return baseMapper.sctzList2(map);
	}
	public List<Map> tzxxtj(Map<String, Object> map) {
		return baseMapper.tzxxtj(map);
	}
	public List<Map> tzxxtjByQy(Map<String, Object> map) {
		return baseMapper.tzxxtjByQy(map);
	}

	@Override
	public List<TzxxExcel> exportTzxx(Tzxx tzxx) {
		List<TzxxExcel> tzxxExcel = baseMapper.exportTzxx(tzxx);
		return tzxxExcel;
	}

	@Override
	public List<TzxxExcel> exportQrd(Tzxx tzxx) {
		List<TzxxExcel> tzxxExcel = baseMapper.exportQrd(tzxx);
		return tzxxExcel;
	}

	@Override
	public List<TzxxExcelYD> exportQrdYD(Tzxx tzxx) {
		List<TzxxExcelYD> tzxxExcel = baseMapper.exportQrdYD(tzxx);
		return tzxxExcel;
	}
	@Override
	public List<Map> mapList(Map<String, Object> map) {
		return baseMapper.mapList(map);
	}



	@Override
	public void importTzxx(List<TzxxZgdExcel> data) {

		List<Tzxx> tzxxList = new ArrayList<>();
		for (int i=0; i<data.size(); i++) {
			TzxxZgdExcel tzxxZgdExcel = data.get(i);
			Tzxx tzxx = Objects.requireNonNull(BeanUtil.copy(tzxxZgdExcel, Tzxx.class));

			tzxx.setYf(TzxxZgdImportListener.DFNY);
			if(tzxx.getYhbh() != null){
				tzxxList.add(tzxx);
			}

		}
		this.saveBatch(tzxxList);
	}
}
