/**
 * Copyright (c) 2018-2028, Chill Zhuang 庄骞 (smallchill@163.com).
 * <p>
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * <p>
 * http://www.apache.org/licenses/LICENSE-2.0
 * <p>
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.springblade.modules.ttdf.excel;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import lombok.Data;

/**
 * 台账信息实体类
 *
 * @author Blade
 * @since 2023-05-19
 */
@Data
@TableName("ttdf_tzxx")
public class TzxxZgdExcel {

    private static final long serialVersionUID = 1L;


    /**
     * 供电所
     */
	@ColumnWidth(15)
    @ExcelProperty(index = 1)
    private String gds;

	/**
	 * 电表编号
	 */
	@ExcelProperty(index = 2)
	private String dbbh;

	/**
	 * 区域
	 */
	@ExcelProperty(index = 3)
	private String qy;
	/**
	 * 月份
	 */
	@ExcelProperty(index = 4)
	private String yf;

	/**
	 * 站点编码
	 */
	@ExcelProperty(index = 5)
	private String zdbm;
	/**
	 * 站名
	 */
	@ExcelProperty(index = 6)
	private String zhm;
	/**
	 * 分摊系数
	 */
	@ExcelProperty(index = 7)
	private String ftxs;

    /**
     * 用户编号
     */
    @ExcelProperty(index = 8)
    private String yhbh;
    /**
     * 运营商
     */
    @ExcelProperty(index = 9)
    private String yys;
    /**
     * 供电方式
     */
    @ExcelProperty(index = 10)
    private String gdfs;
    /**
     * 基础数据总计
     */
    @ExcelProperty(index = 11)
    private Double jczj;
    /**
     * 移动4G
     */
    @ExcelProperty(index = 12)
    private Double yd4g;
    /**
     * 联通4G
     */
    @ExcelProperty(index = 13)
    private Double lt4g;
    /**
     * 电信4G
     */
    @ExcelProperty(index = 14)
    private Double dx4g;
    /**
     * 拓展业务基数
     */
    @ExcelProperty(index = 15)
    private String tzywjs;
    /**
     * 移动5G
     */
    @ExcelProperty(index = 16)
    private Double yd5g;
    /**
     * 联通5G
     */
    @ExcelProperty(index = 17)
    private Double lt5g;
    /**
     * 电信5G
     */
    @ExcelProperty(index = 18)
    private Double dx5g;
    /**
     * 总计分摊比例
     */
    @ExcelProperty(index = 19)
    private String zjftbl;
    /**
     * 移动分摊比例4G
     */
    @ExcelProperty(index = 20)
    private String ydftbl4g;
    /**
     * 联通分摊比例4G
     */
    @ExcelProperty(index = 21)
    private String ltftbl4g;
    /**
     * 电信分摊比例4G
     */
    @ExcelProperty(index = 22)
    private String dxftbl4g;
    /**
     * 拓展业务比例
     */
    @ExcelProperty(index = 23)
    private String tzywbl;
    /**
     * 移动分摊比例5G
     */
    @ExcelProperty(index = 24)
    private String ydftbl5g;
    /**
     * 联通分摊比例5G
     */
    @ExcelProperty(index = 25)
    private String ltftbl5g;
    /**
     * 电信分摊比例5G
     */
    @ExcelProperty(index = 26)
    private String dxftbl5g;
    /**
     * 上次抄表日期
     */
    @ExcelProperty(index = 27)
    private String sccbrq;
    /**
     * 本次抄表日期
     */
    @ExcelProperty(index = 28)
    private String bccbrq;
    /**
     * 上次表数
     */
    @ExcelProperty(index = 29)
    private String scbs;
    /**
     * 止码
     */
    @ExcelProperty(index = 30)
    private String zm;
    /**
     * 用电量
     */
    @ExcelProperty(index = 31)
    private String ydl;
    /**
     * 金额
     */
    @ExcelProperty(index = 32)
    private String jine;
    /**
     * 分摊系数账单金额
     */
    @ExcelProperty(index = 33)
    private String ftxszdje;
    /**
     * 校验电费列
     */
    @ExcelProperty(index = 34)
    private String jydfl;
    /**
     * 电费分摊_移动4g
     */
    @ExcelProperty(index = 35)
    private String dfftYd4g;
    /**
     * 电费分摊_联通4g
     */
    @ExcelProperty(index = 36)
    private String dfftLt4g;
    /**
     * 电费分摊_电信4g
     */
    @ExcelProperty(index = 37)
    private String dfftDx4g;
    /**
     * 电费分摊_拓展业务
     */
    @ExcelProperty(index = 38)
    private String dfftTzyw;
    /**
     * 电费分摊_移动5g
     */
    @ExcelProperty(index = 39)
    private String dfftYd5g;
    /**
     * 电费分摊_联通5g
     */
    @ExcelProperty(index = 40)
    private String dfftLt5g;
    /**
     * 电费分摊_电信5g
     */
    @ExcelProperty(index = 41)
    private String dfftDx5g;
    /**
     * 电费分摊_合计电费
     */
    @ExcelProperty(index = 42)
    private String dfftHjdf;
    /**
     * 电量分摊_移动4g
     */
    @ExcelProperty(index = 43)
    private String dlftYd4g;
    /**
     * 电量分摊_联通4g
     */
    @ExcelProperty(index = 44)
    private String dlftLt4g;
    /**
     * 电量分摊_电信4g
     */
    @ExcelProperty(index = 45)
    private String dlftDx4g;
    /**
     * 电量分摊_拓展业务
     */
    @ExcelProperty(index = 46)
    private String dlftTzyw;
    /**
     * 电量分摊_移动5g
     */
    @ExcelProperty(index = 47)
    private String dlftYd5g;
    /**
     * 电量分摊_联通5g
     */
    @ExcelProperty(index = 48)
    private String dlftLt5g;
    /**
     * 电量分摊_电信5g
     */
    @ExcelProperty(index = 49)
    private String dlftDx5g;
    /**
     * 电量分摊_合计电量
     */
    @ExcelProperty(index = 50)
    private String dlftHjdf;
    /**
     * 分摊后电费(含税不含农网费)4G_移动
     */
    @ExcelProperty(index = 51)
    private String fthdfYd4g;
    /**
     * 分摊后电费(含税不含农网费)4G_联通
     */
    @ExcelProperty(index = 52)
    private String fthdfLt4g;
    /**
     * 分摊后电费(含税不含农网费)4G_电信
     */
    @ExcelProperty(index = 53)
    private String fthdfDx4g;
    /**
     * 分摊后电费(含税不含农网费)4G_拓展业务
     */
    @ExcelProperty(index = 54)
    private String fthdfTzyw;
    /**
     * 分摊后电费(含税不含农网费)5G_移动
     */
    @ExcelProperty(index = 55)
    private String fthdfYd5g;
    /**
     * 分摊后电费(含税不含农网费)5G_联通
     */
    @ExcelProperty(index = 56)
    private String fthdfLt5g;
    /**
     * 分摊后电费(含税不含农网费)5G_电信
     */
    @ExcelProperty(index = 57)
    private String fthdfDx5g;
    /**
     * 分摊后农网费_移动
     */
    @ExcelProperty(index = 58)
    private String fthnwfYd;
    /**
     * 分摊后农网费_联通
     */
    @ExcelProperty(index = 59)
    private String fthnwfLt;
    /**
     * 分摊后农网费_电信
     */
    @ExcelProperty(index = 60)
    private String fthnwfDx;
    /**
     * 分摊后农网费_拓展业务
     */
    @ExcelProperty(index = 61)
    private String fthnwfTzyw;
    /**
     * 分摊后农网费_合计
     */
    @ExcelProperty(index = 62)
    private String fthnwfHj;
    /**
     * 税负因子_移动4G税负因子
     */
    @ExcelProperty(index = 63)
    private String sfyzYd4g;
    /**
     * 税负因子_联通4G税负因子
     */
    @ExcelProperty(index = 64)
    private String sfyzLt4g;
    /**
     * 税负因子_电信4G税负因子
     */
    @ExcelProperty(index = 65)
    private String sfyzDx4g;
    /**
     * 税负因子_移动5G税负因子
     */
    @ExcelProperty(index = 66)
    private String sfyzYd5g;
    /**
     * 税负因子_联通5G税负因子
     */
    @ExcelProperty(index = 67)
    private String sfyzLt5g;
    /**
     * 税负因子_电信5G税负因子
     */
    @ExcelProperty(index = 68)
    private String sfyzDx5g;
    /**
     * 税负因子_税负因子总计
     */
    @ExcelProperty(index = 69)
    private String sfyzZj;
    /**
     * 税负因子_移动4G分摊
     */
    @ExcelProperty(index = 70)
    private String sfyzYd4gFt;
    /**
     * 税负因子_联通4G分摊
     */
    @ExcelProperty(index = 71)
    private String sfyzLt4gFt;
    /**
     * 税负因子_电信4G分摊
     */
    @ExcelProperty(index = 72)
    private String sfyzDx4gFt;
    /**
     * 税负因子_拓展能源
     */
    @ExcelProperty(index = 73)
    private String sfyzTznyFt;
    /**
     * 税负因子_移动5G分摊
     */
    @ExcelProperty(index = 74)
    private String sfyzYd5gFt;
    /**
     * 税负因子_联通5G分摊
     */
    @ExcelProperty(index = 75)
    private String sfyzLt5gFt;
    /**
     * 税负因子_电信5G分摊
     */
    @ExcelProperty(index = 76)
    private String sfyzDx5gFt;
    /**
     * 税负因子_最终分摊合计
     */
    @ExcelProperty(index = 77)
    private String sfyzFthj;
    /**
     * 一站多表
     */
    @ExcelProperty(index = 78)
    private String yzdb;
    /**
     * 一表多站
     */
    @ExcelProperty(index = 79)
    private String ybdz;
    /**
     * 备注(一表一站)
     */
    @ExcelProperty(index = 80)
    private String bzybyz;
    /**
     * 钉钉流程编号
     */
    @ExcelProperty(index = 81)
    private String ddlcbh;


}
