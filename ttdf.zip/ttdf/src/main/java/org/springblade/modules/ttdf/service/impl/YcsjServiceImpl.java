/**
 * Copyright (c) 2018-2028, Chill Zhuang 庄骞 (smallchill@163.com).
 * <p>
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * <p>
 * http://www.apache.org/licenses/LICENSE-2.0
 * <p>
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.springblade.modules.ttdf.service.impl;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springblade.modules.ttdf.entity.Ycsj;
import org.springblade.modules.ttdf.vo.YcsjVO;
import org.springblade.modules.ttdf.mapper.YcsjMapper;
import org.springblade.modules.ttdf.service.IYcsjService;
import org.springblade.core.mp.base.BaseServiceImpl;
import org.springframework.stereotype.Service;
import com.baomidou.mybatisplus.core.metadata.IPage;

import java.util.List;
import java.util.Map;

/**
 * 异常数据 服务实现类
 *
 * @author Blade
 * @since 2023-05-09
 */
@Service
public class YcsjServiceImpl extends ServiceImpl<YcsjMapper, Ycsj> implements IYcsjService {

	@Override
	public IPage<YcsjVO> selectYcsjPage1(IPage<YcsjVO> page, YcsjVO ycsj) {
		return page.setRecords(baseMapper.selectYcsjPage1(page, ycsj));
	}
	@Override
	public IPage<YcsjVO> selectYcsjPage2(IPage<YcsjVO> page, YcsjVO ycsj) {
		return page.setRecords(baseMapper.selectYcsjPage2(page, ycsj));
	}
	@Override
	public IPage<YcsjVO> selectYcsjPage3(IPage<YcsjVO> page, YcsjVO ycsj) {
		return page.setRecords(baseMapper.selectYcsjPage3(page, ycsj));
	}
	@Override
	public IPage<YcsjVO> selectYcsjPage4(IPage<YcsjVO> page, YcsjVO ycsj) {
		return page.setRecords(baseMapper.selectYcsjPage4(page, ycsj));
	}


	@Override
	public YcsjVO selectYcsj1(Map<String,Object> params) {
		return baseMapper.selectYcsjPage1(params);
	}
	@Override
	public YcsjVO selectYcsj2(Map<String,Object> params) {
		return baseMapper.selectYcsjPage2(params);
	}
	@Override
	public YcsjVO selectYcsj3(Map<String,Object> params) {
		return baseMapper.selectYcsjPage3(params);
	}
	@Override
	public YcsjVO selectYcsj4(Map<String,Object> params) {
		return baseMapper.selectYcsjPage4(params);
	}
	@Override
	public List<Map> ycTj(Map<String, Object> map) {
		return baseMapper.ycTj(map);
	}

	@Override
	public List<Map> ycTjByQy(Map<String, Object> map) {
		return baseMapper.ycTjByQy(map);
	}
}
