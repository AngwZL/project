/**
 * Copyright (c) 2018-2028, Chill Zhuang 庄骞 (smallchill@163.com).
 * <p>
 * Licensed under the GNU LESSER GENERAL PUBLIC LICENSE 3.0;
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * <p>
 * http://www.gnu.org/licenses/lgpl.html
 * <p>
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.springblade.modules.ttdf.controller;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.AllArgsConstructor;
import org.jetbrains.annotations.NotNull;
import org.springblade.core.boot.ctrl.BladeController;
import org.springblade.core.mp.support.Condition;
import org.springblade.core.mp.support.Query;
import org.springblade.core.tool.api.R;
import org.springblade.core.tool.utils.Func;
import org.springblade.modules.ttdf.entity.Tzxx;
import org.springblade.modules.ttdf.service.ITzxxService;
import org.springblade.modules.ttdf.service.IYcsjService;
import org.springblade.modules.ttdf.service.IYldfService;
import org.springblade.modules.ttdf.vo.TzxxVO;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 首页统计 控制器
 *
 * @author Blade
 * @since 2023-05-19
 */
@RestController
@AllArgsConstructor
@RequestMapping("/ttdf/wel")
@Api(value = "台账信息", tags = "台账信息接口")
public class WelController extends BladeController {

	private ITzxxService tzxxService;

	private IYcsjService ycsjService;
	private IYldfService yldfService;
	/**
	 * 电量统计
	 */
	@GetMapping("/dlTj")
	public R<Map> tzxxtj(@RequestParam Map<String, Object> params) {
		Map<String, Object> result = new HashMap<>();

		params.put("yf",params.get("dfny"));
		List<Map> list = tzxxService.tzxxtj(params);
		if(list.size()>0){
			result = list.get(0);
		}
		return R.data(result);
	}

	/**
	 * 电量分区域统计
	 */
	@GetMapping("/dlTjByQy")
	public R<List<Map>> dlTjByQy(@RequestParam Map<String, Object> params) {
		Map<String, Object> result = new HashMap<>();
		params.put("yf",params.get("dfny"));
		List<Map> list = tzxxService.tzxxtjByQy(params);
		return R.data(list);
	}

	/**
	 * 异常统计
	 */
	@GetMapping("/ycTj")
	public R<Map> ycTj(@RequestParam Map<String, Object> params) {
		Map<String, Object> result = new HashMap<>();
		List<Map> list = ycsjService.ycTj(params);
		if(list.size()>0){
			result = list.get(0);
		}
		return R.data(result);
	}

	/**
	 * 异常分区域统计
	 */
	@GetMapping("/ycTjByQy")
	public R<List<Map>> ycTjByQy(@RequestParam Map<String, Object> params) {
		Map<String, Object> result = new HashMap<>();
		params.put("sj","2023年5月");
		List<Map> list = ycsjService.ycTjByQy(params);
		return R.data(list);
	}

	/**
	 * 地图坐标点
	 */
	@GetMapping("/mapList")
	public R<List<Map>> mapList(@RequestParam Map<String, Object> params) {
		Map<String, Object> result = new HashMap<>();
		List<Map> list = tzxxService.mapList(params);
		return R.data(list);
	}

	/**
	 * 遗留电费统计
	 */
	@GetMapping("/yldfTj")
	public R<Map> yldfTj(@NotNull @RequestParam Map<String, Object> params) {
		Map<String, Object> result = new HashMap<>();
		params.put("yf",params.get("dfny"));
		List<Map> list = yldfService.yltj(params);
		if(list.size()>0){
			result = list.get(0);
			result.put("ydWqr",String.format("%.2f",Double.parseDouble(list.get(0).get("wqr_dx4g").toString())+Double.parseDouble(list.get(0).get("wqr_dx5g").toString())));
			result.put("ltWqr",String.format("%.2f",Double.parseDouble(list.get(0).get("wqr_lt4g").toString())+Double.parseDouble(list.get(0).get("wqr_lt5g").toString())));
			result.put("dxWqr",String.format("%.2f",Double.parseDouble(list.get(0).get("wqr_yd4g").toString())+Double.parseDouble(list.get(0).get("wqr_yd5g").toString())));
		}
		return R.data(result);
	}
}
