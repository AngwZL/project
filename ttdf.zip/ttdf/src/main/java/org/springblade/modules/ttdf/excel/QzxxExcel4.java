/**
 * Copyright (c) 2018-2028, Chill Zhuang 庄骞 (smallchill@163.com).
 * <p>
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * <p>
 * http://www.apache.org/licenses/LICENSE-2.0
 * <p>
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.springblade.modules.ttdf.excel;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import lombok.Data;

import java.io.Serializable;

/**
 * UserDTO
 *
 * @author Chill
 */
@Data
@ColumnWidth(25)
@HeadRowHeight(20)
@ContentRowHeight(18)
public class QzxxExcel4 implements Serializable {
	private static final long serialVersionUID = 1L;
	/**
	 * 站址编码
	 */
	@ExcelProperty(index = 10)
	private String zzbm;
	/**
	 * 站址名称
	 */
	@ExcelProperty(index = 9)
	private String zhm;
	/**
	 * 运营商站址名称
	 */
	@ExcelProperty(index = 8)
	private String yysZhm;
	/**
	 * 区域
	 */
	@ExcelProperty(index = 6)
	private String qy;
	/**
	 * 运营商
	 */
	@ExcelProperty(index = 3)
	private String yys;
	/**
	 * 经度
	 */
	@ExcelProperty(index = 18)
	private String jingdu;
	/**
	 * 纬度
	 */
	@ExcelProperty(index = 19)
	private String weidu;

	/**
	 * 订单状态
	 */
	@ExcelProperty(index = 1)
	private String status;
	/**
	 * 数据时间
	 */
	private String sj;
	/**
	 * 详细地址
	 */
	@ExcelProperty(index = 20)
	private String xxdz;
	/**
	 * 机房类型
	 */
	@ExcelProperty(index = 79)
	private String jflx;
}
