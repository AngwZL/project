/**
 * Copyright (c) 2018-2028, Chill Zhuang 庄骞 (smallchill@163.com).
 * <p>
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * <p>
 * http://www.apache.org/licenses/LICENSE-2.0
 * <p>
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.springblade.modules.ttdf.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springblade.core.mp.support.Condition;
import org.springblade.core.tool.api.R;
import org.springblade.core.tool.utils.BeanUtil;
import org.springblade.modules.ttdf.entity.Clhsj;
import org.springblade.modules.ttdf.entity.Jcsj;
import org.springblade.modules.ttdf.entity.Tzftxx;
import org.springblade.modules.ttdf.entity.Ycxx;
import org.springblade.modules.ttdf.excel.ClhsjExcel;
import org.springblade.modules.ttdf.excel.ClhsjImportListener;
import org.springblade.modules.ttdf.excel.TzftxxExcel;
import org.springblade.modules.ttdf.excel.TzftxxImportListener;
import org.springblade.modules.ttdf.mapper.YcxxMapper;
import org.springblade.modules.ttdf.vo.TzftxxVO;
import org.springblade.modules.ttdf.mapper.TzftxxMapper;
import org.springblade.modules.ttdf.service.ITzftxxService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.baomidou.mybatisplus.core.metadata.IPage;

import java.util.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.util.List;

/**
 * 台账分摊信息 服务实现类
 *
 * @author Blade
 * @since 2023-05-09
 */
@Service
public class TzftxxServiceImpl extends ServiceImpl<TzftxxMapper, Tzftxx> implements ITzftxxService {
	@Autowired
	private YcxxMapper ycxxMapper;
	@Override
	public IPage<TzftxxVO> selectTzftxxPage(IPage<TzftxxVO> page, TzftxxVO tzftxx) {
		return page.setRecords(baseMapper.selectTzftxxPage(page, tzftxx));
	}

	@Override
	public List<TzftxxVO> listByYhbh(Map<String ,Object> tzftxx) {
		return baseMapper.listByYhbh(tzftxx);
	}


	@Override
	public void update(Tzftxx tzftxx) {
		try {
			baseMapper.updateById(tzftxx);
		} catch (Exception e) {

		}
	}

	@Override
	public IPage<Map> pageYC(IPage<Map> page, TzftxxVO tzftxx) {
		List<Map> maps = baseMapper.pageYC(page, tzftxx);
		maps.stream().forEach(map -> map.putIfAbsent("status",null));
		return page.setRecords(maps);
	}

	@Override
	public boolean save(Tzftxx tzftxx) {
		try {
			baseMapper.insert(tzftxx);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		return true;
	}
	@Override
	public R mark(Ycxx ycxx) {
		ycxxMapper.insertYcxx(ycxx);
		return R.success("操作成功");
	}

	@Override
	public R cancelMark(String yw_id) {
		ycxxMapper.delete(new LambdaQueryWrapper<Ycxx>().eq(Ycxx::getYw_id, yw_id));
		return R.success("操作成功");
	}

	@Override
	public List<Map> tzftYcsj(TzftxxVO tzftxx) {
		return baseMapper.pageYC(tzftxx);
	}
	@Override
	public List<Map> queryYhbh(Map<String, Object> map) {
		return baseMapper.queryYhbh(map);
	}
	@Override
	public List<Map> queryDbbh(Map<String, Object> map) {
		return baseMapper.queryDbbh(map);
	}
	@Override
	public List<Map> queryZhm(Map<String, Object> map) {
		return baseMapper.queryZhm(map);
	}
	@Override
	public List<Map> queryZdbm(Map<String, Object> map) {
		return baseMapper.queryZdbm(map);
	}


	@Override
	public void importTzftxx(List<TzftxxExcel> data) {

		List<Tzftxx> tzftxxList = new ArrayList<>();
		for (int i=0; i<data.size(); i++) {
			TzftxxExcel tzftxxExcel = data.get(i);
			Tzftxx tzftxx = Objects.requireNonNull(BeanUtil.copy(tzftxxExcel, Tzftxx.class));
			if(tzftxx.getQy().indexOf("阳新")>-1){
				tzftxx.setQy("阳新");
			}else if(tzftxx.getQy().indexOf("大冶")>-1){
				tzftxx.setQy("大冶");
			}else{
				tzftxx.setQy("现业");
			}
			if(tzftxx.getYd4g() == null || "".equals(tzftxx.getYd4g())){
				tzftxx.setYd4g(0d);
			}
			if(tzftxx.getYd5g() == null || "".equals(tzftxx.getYd5g())){
				tzftxx.setYd5g(0d);
			}
			if(tzftxx.getLt4g() == null || "".equals(tzftxx.getLt4g())){
				tzftxx.setLt4g(0d);
			}
			if(tzftxx.getLt5g() == null || "".equals(tzftxx.getLt5g())){
				tzftxx.setLt5g(0d);
			}
			if(tzftxx.getDx4g() == null || "".equals(tzftxx.getDx4g())){
				tzftxx.setDx4g(0d);
			}
			if(tzftxx.getDx5g() == null || "".equals(tzftxx.getDx5g())){
				tzftxx.setDx5g(0d);
			}
			if(tzftxx.getTzywjs() == null || "".equals(tzftxx.getTzywjs())){
				tzftxx.setTzywjs(0d);
			}

			if(tzftxx.getZjftbl() == null || tzftxx.getZjftbl().indexOf("DIV")>0){
				tzftxx.setZjftbl("100%");
			}
			if(tzftxx.getYdftbl4g() == null || tzftxx.getYdftbl4g().indexOf("DIV")>0){
				tzftxx.setYdftbl4g("0%");
			}
			if(tzftxx.getLtftbl4g()== null || tzftxx.getLtftbl4g().indexOf("DIV")>0){
				tzftxx.setLtftbl4g("0%");
			}
			if(tzftxx.getDxftbl4g()== null || tzftxx.getDxftbl4g().indexOf("DIV")>0){
				tzftxx.setDxftbl4g("0%");
			}
			if(tzftxx.getTzywbl()== null || tzftxx.getTzywbl().indexOf("DIV")>0){
				tzftxx.setTzywbl("0%");
			}
			if(tzftxx.getYdftbl5g()== null || tzftxx.getYdftbl5g().indexOf("DIV")>0){
				tzftxx.setYdftbl5g("0%");
			}
			if(tzftxx.getLtftbl5g()== null || tzftxx.getLtftbl5g().indexOf("DIV")>0){
				tzftxx.setLtftbl5g("0%");
			}
			if(tzftxx.getDxftbl5g()== null || tzftxx.getDxftbl5g().indexOf("DIV")>0){
				tzftxx.setDxftbl5g("0%");
			}

			tzftxx.setYf(TzftxxImportListener.DFNY);
			tzftxxList.add(tzftxx);
		}
		this.saveBatch(tzftxxList);
	}
}
