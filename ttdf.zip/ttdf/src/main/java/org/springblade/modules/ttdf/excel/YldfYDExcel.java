/**
 * Copyright (c) 2018-2028, Chill Zhuang 庄骞 (smallchill@163.com).
 * <p>
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * <p>
 * http://www.apache.org/licenses/LICENSE-2.0
 * <p>
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.springblade.modules.ttdf.excel;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import lombok.Data;

/**
 * 台账信息实体类
 *
 * @author Blade
 * @since 2023-05-19
 */
@Data
@TableName("ttdf_tzxx")
@ApiModel(value = "Tzxx对象", description = "遗留电费信息")
public class YldfYDExcel {

    private static final long serialVersionUID = 1L;

    /**
     * 报账点名称
     */
	@ColumnWidth(15)
    @ExcelProperty(value = "报账点名称")
    private String bzdmc;

	/**
	 * 金额
	 */
	@ExcelProperty(value = "调整后汇总金额(实际推送金额)")
	private String jine;

	/**
	 * 月份
	 */
	@ExcelProperty(value = "缴费期始")
	private String startYf;

	/**
	 * 月份
	 */
	@ExcelProperty(value = "缴费期终")
	private String endYf;
}
