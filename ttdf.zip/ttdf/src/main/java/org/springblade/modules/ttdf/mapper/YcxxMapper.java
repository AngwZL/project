package org.springblade.modules.ttdf.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Insert;
import org.springblade.modules.ttdf.entity.Ycxx;
/**
 * 异常信息 Mapper 接口
 *
 */
public interface YcxxMapper extends BaseMapper<Ycxx> {
	@Insert("insert into ttdf_ycxx(type, yw_id, status, sj) VALUES(#{type},#{yw_id},#{status},#{sj})")
	void insertYcxx(Ycxx ycxx);
}
