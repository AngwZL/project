package org.springblade.modules.ttdf.excel;

import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.event.AnalysisEventListener;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.RequiredArgsConstructor;
import org.springblade.modules.ttdf.service.IClhsjService;
import org.springblade.modules.ttdf.service.IYldfService;

import java.util.ArrayList;
import java.util.List;

/**
 * UserImportListener
 *
 * @author Chill
 */
@Data
@RequiredArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class YldfImportListener extends AnalysisEventListener<YldfExcel> {

	public static String DFNY="";
	public static String yys="";
	/**
	 * 默认每隔3000条存储数据库
	 */
	private int batchCount = 10000;
	/**
	 * 缓存的数据列表
	 */
	private List<YldfExcel> list = new ArrayList<>();
	/**
	 * 用户service
	 */
	private final IYldfService yldfService;

	@Override
	public void invoke(YldfExcel data, AnalysisContext context) {
		data.setStartYf(data.getYf());
		data.setEndYf(data.getYf());
		data.setYys(yys);
		if(data.getYys().equals("联通")){
			data.setType(1);
			data.setQrje(data.getSfyzLt4gFt());
		}
		if(data.getYys().equals("电信_4g")){
			data.setType(2);
			data.setYys("电信");
			data.setQrje(data.getSfyzDx4gFt());
		}
		if(data.getYys().equals("电信_5g")){
			data.setType(3);
			data.setYys("电信");
			data.setQrje(data.getSfyzDx5gFt());
		}
		list.add(data);
		// 达到BATCH_COUNT，则调用importer方法入库，防止数据几万条数据在内存，容易OOM
		if (list.size() >= batchCount) {
			// 调用importer方法
			yldfService.importYldf(list);
			// 存储完成清理list
			list.clear();
		}
	}

	@Override
	public void doAfterAllAnalysed(AnalysisContext analysisContext) {
		// 调用importer方法
		yldfService.importYldf(list);
		// 存储完成清理list
		list.clear();
	}

}
