package org.springblade.modules.ttdf.excel;

import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.event.AnalysisEventListener;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.RequiredArgsConstructor;
import org.springblade.modules.ttdf.entity.Tzftxx;
import org.springblade.modules.ttdf.service.ITzftxxService;
import org.springblade.modules.ttdf.service.IYldfService;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * UserImportListener
 *
 * @author Chill
 */
@Data
@RequiredArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class YldfYDImportListener extends AnalysisEventListener<YldfYDExcel> {

	public static String DFNY="";
	public static String yys="";
	/**
	 * 默认每隔3000条存储数据库
	 */
	private int batchCount = 10000;
	/**
	 * 缓存的数据列表
	 */
	private List<YldfExcel> list = new ArrayList<>();
	/**
	 * 用户service
	 */
	private final IYldfService yldfService;
	private final ITzftxxService tzftxxService;

	@Override
	public void invoke(YldfYDExcel data, AnalysisContext context) {
		YldfExcel yldfExcel = new YldfExcel();
		String bzdmc[] = data.getBzdmc().split("_");
		yldfExcel.setZdbm(bzdmc[bzdmc.length-1]);

		yldfExcel.setYys("移动");
		yldfExcel.setType(1);
		yldfExcel.setQrje(data.getJine());

		Map<String , Object> param = new HashMap<>();
		param.put("zdbm", yldfExcel.getZdbm());
		List<Tzftxx> listZd = tzftxxService.listByMap(param);
		if(listZd.size()>0){
			Tzftxx tzftxx = listZd.get(0);
			yldfExcel.setQy(tzftxx.getQy());
			yldfExcel.setZhm(tzftxx.getZhm());
		}

		String[] startYf = data.getStartYf().split("-");
		if(startYf[1].startsWith("0")){
			yldfExcel.setStartYf(startYf[0]+"年"+startYf[1].substring(1,2)+"月");
		}else{
			yldfExcel.setStartYf(startYf[0]+"年"+startYf[1]+"月");
		}

		String[] endYf = data.getEndYf().split("-");
		if(endYf[1].startsWith("0")){
			if(endYf[2].startsWith("2")||endYf[2].startsWith("3")){
				yldfExcel.setEndYf(endYf[0]+"年"+endYf[1].substring(1,2)+"月");
			}else{
				if(endYf[1].startsWith("01")){
					yldfExcel.setEndYf((Integer.parseInt(endYf[0])-1)+"年"+(12)+"月");
				}else{
					yldfExcel.setEndYf(endYf[0]+"年"+(Integer.parseInt(endYf[1].substring(1,2))-1)+"月");
				}

			}

		}else{
			if(endYf[2].startsWith("2")||endYf[2].startsWith("3")){
				yldfExcel.setEndYf(endYf[0]+"年"+endYf[1]+"月");
			}else{
				if(endYf[1].startsWith("01")){
					yldfExcel.setEndYf((Integer.parseInt(endYf[0])-1)+"年"+(12)+"月");
				}else{
					yldfExcel.setEndYf(endYf[0]+"年"+(Integer.parseInt(endYf[1])-1)+"月");
				}

			}
		}

		list.add(yldfExcel);
		// 达到BATCH_COUNT，则调用importer方法入库，防止数据几万条数据在内存，容易OOM
		System.out.println(list.size());
		if (list.size() >= batchCount) {
			// 调用importer方法
			yldfService.importYldf(list);
			// 存储完成清理list
			System.out.println("保存数据");
			list.clear();

		}
	}

	@Override
	public void doAfterAllAnalysed(AnalysisContext analysisContext) {
		// 调用importer方法
		yldfService.importYldf(list);
		//System.out.println("保存数据");
		// 存储完成清理list
		list.clear();
	}

}
