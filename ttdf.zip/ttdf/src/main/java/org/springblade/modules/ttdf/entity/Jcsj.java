/**
 * Copyright (c) 2018-2028, Chill Zhuang 庄骞 (smallchill@163.com).
 * <p>
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * <p>
 * http://www.apache.org/licenses/LICENSE-2.0
 * <p>
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.springblade.modules.ttdf.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import org.springblade.core.mp.base.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 基础数据实体类
 *
 * @author Blade
 * @since 2023-05-09
 */
@Data
@TableName("ttdf_jcsj")
@ApiModel(value = "Jcsj对象", description = "基础数据")
public class Jcsj {

    private static final long serialVersionUID = 1L;

	  @TableId(value = "id", type = IdType.AUTO)
	  private Integer id;
    /**
     * 用户编号
     */
    @ApiModelProperty(value = "用户编号")
    private String yhbh;
    /**
     * 出厂编号
     */
    @ApiModelProperty(value = "出厂编号")
    private String ccbh;
    /**
     * 表类型
     */
    @ApiModelProperty(value = "表类型")
    private String blx;
    /**
     * 用电地址
     */
    @ApiModelProperty(value = "用电地址")
    private String yddz;

	/**
	 * 营业所
	 */
	@ApiModelProperty(value = "营业所")
	private String yys;

	/**
	 * 区域
	 */
	@ApiModelProperty(value = "区域")
	private String qy;

	/**
	 * 用户名称
	 */
	@ApiModelProperty(value = "用户名称")
	private String yhmc;
}
