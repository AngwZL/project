/**
 * Copyright (c) 2018-2028, Chill Zhuang 庄骞 (smallchill@163.com).
 * <p>
 * Licensed under the GNU LESSER GENERAL PUBLIC LICENSE 3.0;
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * <p>
 * http://www.gnu.org/licenses/lgpl.html
 * <p>
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.springblade.modules.ttdf.controller;

import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.ExcelReader;
import com.alibaba.excel.read.metadata.ReadSheet;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import lombok.AllArgsConstructor;
import javax.validation.Valid;

import org.springblade.core.mp.support.Condition;
import org.springblade.core.mp.support.Query;
import org.springblade.core.tool.api.R;
import org.springblade.core.tool.utils.Func;
import org.springblade.modules.ttdf.excel.*;
import org.springblade.modules.ttdf.service.ITzftxxService;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.RequestParam;
import com.baomidou.mybatisplus.core.metadata.IPage;
import org.springblade.modules.ttdf.entity.Yldf;
import org.springblade.modules.ttdf.vo.YldfVO;
import org.springblade.modules.ttdf.service.IYldfService;
import org.springblade.core.boot.ctrl.BladeController;
import org.springframework.web.multipart.MultipartFile;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 遗留电费 控制器
 *
 * @author Blade
 * @since 2023-05-09
 */
@RestController
@AllArgsConstructor
@RequestMapping("/ttdf/yldf")
@Api(value = "遗留电费", tags = "遗留电费接口")
public class YldfController extends BladeController {

	private IYldfService yldfService;
	private ITzftxxService tzftxxService;

	/**
	 * 详情
	 */
	@GetMapping("/detail")
	@ApiOperationSupport(order = 1)
	@ApiOperation(value = "详情", notes = "传入yldf")
	public R<Yldf> detail(Yldf yldf) {
		Yldf detail = yldfService.getOne(Condition.getQueryWrapper(yldf));
		return R.data(detail);
	}

	/**
	 * 分页 遗留电费
	 */
	@GetMapping("/list")
	@ApiOperationSupport(order = 2)
	@ApiOperation(value = "分页", notes = "传入yldf")
	public R<IPage<Yldf>> list(Yldf yldf, Query query) {
		IPage<Yldf> pages = yldfService.page(Condition.getPage(query), Condition.getQueryWrapper(yldf));
		return R.data(pages);
	}

	/**
	 * 自定义分页 遗留电费-确认单
	 */
	@GetMapping("/page")
	@ApiOperationSupport(order = 3)
	@ApiOperation(value = "分页", notes = "传入yldf")
	public R<IPage<Map>> page(YldfVO yldf, Query query) {
		Map<String, Object> p = new HashMap<>();
		IPage<Map> pages = yldfService.selectYldfPage(Condition.getPage(query), yldf);
		return R.data(pages);
	}
	/**
	 * 自定义分页 遗留电费-遗留电费
	 */
	@GetMapping("/ylList")
	@ApiOperationSupport(order = 3)
	@ApiOperation(value = "分页", notes = "传入yldf")
	public R<IPage<Map>> ylList(YldfVO yldf, Query query) {
		Map<String, Object> p = new HashMap<>();
		IPage<Map> pages = yldfService.ylList(Condition.getPage(query), yldf);
		return R.data(pages);
	}
	/**
	 * 新增 遗留电费
	 */
	@PostMapping("/save")
	@ApiOperationSupport(order = 4)
	@ApiOperation(value = "新增", notes = "传入yldf")
	public R save(@Valid @RequestBody Yldf yldf) {
		return R.status(yldfService.save(yldf));
	}

	/**
	 * 修改 遗留电费
	 */
	@PostMapping("/update")
	@ApiOperationSupport(order = 5)
	@ApiOperation(value = "修改", notes = "传入yldf")
	public R update(@Valid @RequestBody Yldf yldf) {
		return R.status(yldfService.updateById(yldf));
	}

	/**
	 * 新增或修改 遗留电费
	 */
	@PostMapping("/submit")
	@ApiOperationSupport(order = 6)
	@ApiOperation(value = "新增或修改", notes = "传入yldf")
	public R submit(@Valid @RequestBody Yldf yldf) {
		return R.status(yldfService.saveOrUpdate(yldf));
	}


	/**
	 * 删除 遗留电费
	 */
	@PostMapping("/remove")
	@ApiOperationSupport(order = 7)
	@ApiOperation(value = "逻辑删除", notes = "传入ids")
	public R remove(@ApiParam(value = "主键集合", required = true) @RequestParam String ids) {
		return R.status(yldfService.removeBatchByIds(Func.toLongList(ids)));
	}

	/**
	 * 导入确认单
	 */
	@PostMapping("importQrd")
	@ApiOperationSupport(order = 2)
	@ApiOperation(value = "导入电费确认单", notes = "传入excel")
	public R importClhsj(MultipartFile file, String yys) {
		String filename = file.getOriginalFilename();
		if (StringUtils.isEmpty(filename)) {
			throw new RuntimeException("请上传文件!");
		}
		if ((!StringUtils.endsWithIgnoreCase(filename, ".xls") && !StringUtils.endsWithIgnoreCase(filename, ".xlsx"))) {
			throw new RuntimeException("请上传正确的excel文件!");
		}
		if(yys.equals("移动")){
			InputStream inputStream;
			try {
				YldfYDImportListener importListener = new YldfYDImportListener(yldfService,tzftxxService);
				YldfYDImportListener.yys="移动";
				inputStream = new BufferedInputStream(file.getInputStream());
				ExcelReader excelReader = EasyExcel.read(inputStream).build();
				ReadSheet readSheet0 = EasyExcel.readSheet(0).headRowNumber(1).head(YldfYDExcel.class).registerReadListener(importListener).build();
				excelReader.read(readSheet0);
				return R.success("操作成功");
			} catch (Exception e) {
				e.printStackTrace();
				return R.fail("数据格式错误，请核对后重新导入");
			}
		}else if(yys.equals("联通")){
			InputStream inputStream;
			try {
				YldfImportListener importListener = new YldfImportListener(yldfService);
				YldfImportListener.yys="联通";
				inputStream = new BufferedInputStream(file.getInputStream());
				ExcelReader excelReader = EasyExcel.read(inputStream).build();
				ReadSheet readSheet0 = EasyExcel.readSheet(0).headRowNumber(2).head(YldfExcel.class).registerReadListener(importListener).build();
				excelReader.read(readSheet0);
				return R.success("操作成功");
			} catch (Exception e) {
				e.printStackTrace();
				return R.fail("数据格式错误，请核对后重新导入");
			}
		}else{//电信 电信分4g 5g
			InputStream inputStream;
			try {
				YldfImportListener importListener = new YldfImportListener(yldfService);

				YldfImportListener.yys="电信_4g";
				inputStream = new BufferedInputStream(file.getInputStream());
				ExcelReader excelReader = EasyExcel.read(inputStream).build();
				ReadSheet readSheet0 = EasyExcel.readSheet(0).headRowNumber(2).head(YldfExcel.class).registerReadListener(importListener).build();
				excelReader.read(readSheet0);

				InputStream inputStream1;
				YldfImportListener importListener1 = new YldfImportListener(yldfService);

				YldfImportListener.yys="电信_5g";
				inputStream1 = new BufferedInputStream(file.getInputStream());
				ExcelReader excelReader1 = EasyExcel.read(inputStream1).build();
				ReadSheet readSheet1 = EasyExcel.readSheet(1).headRowNumber(2).head(YldfExcel.class).registerReadListener(importListener1).build();
				excelReader1.read(readSheet1);

				return R.success("操作成功");
			} catch (Exception e) {
				e.printStackTrace();
				return R.fail("数据格式错误，请核对后重新导入");
			}
		}
	}


	/**
	 * 遗留电费统计
	 */
	@GetMapping("/yltj")
	public R<Map> tzxxtj(@RequestParam Map<String, Object> params) {
		Map<String, Object> result = new HashMap<>();

		Map<String, Object> p = new HashMap<>();
		p.put("yf",params.get("startYf"));

		List<Map> list1 = yldfService.yltj(p);
		if(list1.size()>0){
			result.put("total",list1.get(0).get("ylje"));
		}else{
			result.put("total",0);
		}

		p.put("qy","现业");
		List<Map> list2 = yldfService.yltj(p);
		if(list2.size()>0){
			result.put("xianye",list2.get(0).get("ylje"));
		}else{
			result.put("xianye",0);
		}

		p.put("qy","大冶");
		List<Map> list3 = yldfService.yltj(p);
		if(list3.size()>0){
			result.put("daye",list3.get(0).get("ylje"));
		}else{
			result.put("daye",0);
		}

		p.put("qy","阳新");
		List<Map> list4 = yldfService.yltj(p);
		if(list4.size()>0){
			result.put("yangxin",list4.get(0).get("ylje"));
		}else{
			result.put("yangxin",0);
		}
		//result.put("total",total);



		return R.data(result);
	}
}
