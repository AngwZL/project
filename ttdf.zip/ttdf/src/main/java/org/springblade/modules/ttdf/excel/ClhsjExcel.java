/**
 * Copyright (c) 2018-2028, Chill Zhuang 庄骞 (smallchill@163.com).
 * <p>
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * <p>
 * http://www.apache.org/licenses/LICENSE-2.0
 * <p>
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.springblade.modules.ttdf.excel;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import lombok.Data;
import org.springblade.common.tool.NullConverter;

import java.io.Serializable;

/**
 * UserDTO
 *
 * @author Chill
 */
@Data
@ColumnWidth(25)
@HeadRowHeight(20)
@ContentRowHeight(18)
public class ClhsjExcel implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 * 用户编号
	 */
	@ExcelProperty(value = "用户编号")
	private String yhbh;
	/**
	 * 营业所
	 */
	@ExcelProperty(value = "营业所")
	private String yys;



	/**
	 * 起码
	 */
	@ExcelProperty(value = "起码", converter = NullConverter.class)
	private Double qm;
	/**
	 * 止码
	 */
	@ExcelProperty(value = "止码", converter = NullConverter.class)
	private Double zm;
	/**
	 * 表类型
	 */
	@ExcelProperty(value = "表类型")
	private String blx;
	/**
	 * 换表记录
	 */
	@ExcelProperty(value = "换表记录")
	private String hbjl;
	/**
	 * 本次电量
	 */
	@ExcelProperty(value = "本次电量", converter = NullConverter.class)
	private Double bcdl;

	/**
	 * 电费金额
	 */
	@ExcelProperty(value = "电费金额", converter = NullConverter.class)
	private Double dfje;

	/**
	 * 实收金额
	 */
	@ExcelProperty(value = "实收金额", converter = NullConverter.class)
	private Double ssje;

	/**
	 * 用户名称
	 */
	@ExcelProperty(value = "用户名称")
	private String yhmc;
	/**
	 * 用电地址
	 */
	@ExcelProperty(value = "用电地址")
	private String yddz;
	/**
	 * 出厂编号
	 */
	@ExcelProperty(value = "出厂编号")
	private String dbbh;

	/**
	 * 缴费方式
	 */
	@ExcelProperty(value = "缴费方式")
	private String jffs;

	/**
	 * 收费日期
	 */
	@ExcelProperty(value = "收费日期")
	private String sfrq;

	/**
	 * 电费年月
	 */
	@ExcelProperty(value = "电费年月")
	private String dfny;

}
