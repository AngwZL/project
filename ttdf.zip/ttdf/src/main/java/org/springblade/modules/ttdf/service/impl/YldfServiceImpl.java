/**
 * Copyright (c) 2018-2028, Chill Zhuang 庄骞 (smallchill@163.com).
 * <p>
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * <p>
 * http://www.apache.org/licenses/LICENSE-2.0
 * <p>
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.springblade.modules.ttdf.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springblade.core.mp.support.Condition;
import org.springblade.core.tool.utils.BeanUtil;
import org.springblade.modules.ttdf.entity.Clhsj;
import org.springblade.modules.ttdf.entity.Jcsj;
import org.springblade.modules.ttdf.entity.Yldf;
import org.springblade.modules.ttdf.excel.*;
import org.springblade.modules.ttdf.vo.YldfVO;
import org.springblade.modules.ttdf.mapper.YldfMapper;
import org.springblade.modules.ttdf.service.IYldfService;
import org.springblade.core.mp.base.BaseServiceImpl;
import org.springframework.stereotype.Service;
import com.baomidou.mybatisplus.core.metadata.IPage;

import java.util.*;

/**
 * 遗留电费 服务实现类
 *
 * @author Blade
 * @since 2023-05-09
 */
@Service
public class YldfServiceImpl extends ServiceImpl<YldfMapper, Yldf> implements IYldfService {

	@Override
	public IPage<Map> selectYldfPage(IPage<Map> page, YldfVO yldf) {
		return page.setRecords(baseMapper.selectYldfPage(page, yldf));
	}

	@Override
	public IPage<Map> ylList(IPage<Map> page, YldfVO yldf) {
		return page.setRecords(baseMapper.ylList(page, yldf));
	}

	@Override
	public void importYldf(List<YldfExcel> data) {
		List<Yldf> yldfList = new ArrayList<>();
		for (int i=0; i<data.size(); i++) {
			YldfExcel yldfExcel = data.get(i);
			Yldf yldf = Objects.requireNonNull(BeanUtil.copy(yldfExcel, Yldf.class));

			yldfList.add(yldf);
		}
		this.saveBatch(yldfList);
	}

	public List<Map> yltj(Map<String, Object> map) {
		return baseMapper.yltj(map);
	}

	public Map qrdCount(Map<String, Object> map) {
		return baseMapper.qrdCount(map);
	}
}
