package org.springblade.modules.ttdf.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.mapstruct.Named;

@Data
@TableName("ttdf_ycxx")
@ApiModel(value = "Ycxx对象", description = "异常信息")
public class Ycxx {
	private static final long serialVersionUID = 1L;
	/**
	 * Id
	 */
	@TableId(value = "id", type = IdType.AUTO)
	private Integer id;
	/**
	 * 异常类型 1表示分摊异常
	 */
	@ApiModelProperty("异常类型")
	private String type;
	/**
	 * 业务id标识(分摊异常存站点编码)
	 */
	@ApiModelProperty(value = "业务id",required = true)
	private String yw_id;
	/**
	 * 状态:1 标记为正常
	 */
	@ApiModelProperty(value = "状态",required = true)
	private String status;
	/**
	 * 数据时间
	 */
	@ApiModelProperty(value = "数据时间",required = true)
	private String sj;
}
