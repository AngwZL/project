/**
 * Copyright (c) 2018-2028, Chill Zhuang 庄骞 (smallchill@163.com).
 * <p>
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * <p>
 * http://www.apache.org/licenses/LICENSE-2.0
 * <p>
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.springblade.modules.ttdf.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import org.springblade.core.mp.base.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 台账信息实体类
 *
 * @author Blade
 * @since 2023-05-19
 */
@Data
@TableName("ttdf_tzxx")
@ApiModel(value = "Tzxx对象", description = "台账信息")
public class Tzxx {

    private static final long serialVersionUID = 1L;

  @TableId(value = "id", type = IdType.AUTO)
  private Integer id;
    /**
     * 供电所
     */
    @ApiModelProperty(value = "供电所")
    private String gds;
    /**
     * 用户编号
     */
    @ApiModelProperty(value = "用户编号")
    private String yhbh;
    /**
     * 电表编号
     */
    @ApiModelProperty(value = "电表编号")
    private String dbbh;
    /**
     * 区域
     */
    @ApiModelProperty(value = "区域")
    private String qy;
    /**
     * 月份
     */
    @ApiModelProperty(value = "月份")
    private String yf;
    /**
     * 站点编码
     */
    @ApiModelProperty(value = "站点编码")
    private String zdbm;
    /**
     * 站名
     */
    @ApiModelProperty(value = "站名")
    private String zhm;
    /**
     * 分摊系数
     */
    @ApiModelProperty(value = "分摊系数")
    private String ftxs;
    /**
     * 运营商
     */
    @ApiModelProperty(value = "运营商")
    private String yys;
    /**
     * 供电方式
     */
    @ApiModelProperty(value = "供电方式")
    private String gdfs;
    /**
     * 基础数据总计
     */
    @ApiModelProperty(value = "基础数据总计")
    private Double jczj;
    /**
     * 移动4G
     */
    @ApiModelProperty(value = "移动4G")
    private Double yd4g;
    /**
     * 联通4G
     */
    @ApiModelProperty(value = "联通4G")
    private Double lt4g;
    /**
     * 电信4G
     */
    @ApiModelProperty(value = "电信4G")
    private Double dx4g;
    /**
     * 拓展业务基数
     */
    @ApiModelProperty(value = "拓展业务基数")
    private String tzywjs;
    /**
     * 移动5G
     */
    @ApiModelProperty(value = "移动5G")
    private Double yd5g;
    /**
     * 联通5G
     */
    @ApiModelProperty(value = "联通5G")
    private Double lt5g;
    /**
     * 电信5G
     */
    @ApiModelProperty(value = "电信5G")
    private Double dx5g;
    /**
     * 总计分摊比例
     */
    @ApiModelProperty(value = "总计分摊比例")
    private String zjftbl;
    /**
     * 移动分摊比例4G
     */
    @ApiModelProperty(value = "移动分摊比例4G")
    private String ydftbl4g;
    /**
     * 联通分摊比例4G
     */
    @ApiModelProperty(value = "联通分摊比例4G")
    private String ltftbl4g;
    /**
     * 电信分摊比例4G
     */
    @ApiModelProperty(value = "电信分摊比例4G")
    private String dxftbl4g;
    /**
     * 拓展业务比例
     */
    @ApiModelProperty(value = "拓展业务比例")
    private String tzywbl;
    /**
     * 移动分摊比例5G
     */
    @ApiModelProperty(value = "移动分摊比例5G")
    private String ydftbl5g;
    /**
     * 联通分摊比例5G
     */
    @ApiModelProperty(value = "联通分摊比例5G")
    private String ltftbl5g;
    /**
     * 电信分摊比例5G
     */
    @ApiModelProperty(value = "电信分摊比例5G")
    private String dxftbl5g;
    /**
     * 上次抄表日期
     */
    @ApiModelProperty(value = "上次抄表日期")
    private String sccbrq;
    /**
     * 本次抄表日期
     */
    @ApiModelProperty(value = "本次抄表日期")
    private String bccbrq;
    /**
     * 上次表数
     */
    @ApiModelProperty(value = "上次表数")
    private String scbs;
    /**
     * 止码
     */
    @ApiModelProperty(value = "止码")
    private String zm;
    /**
     * 用电量
     */
    @ApiModelProperty(value = "用电量")
    private String ydl;
    /**
     * 金额
     */
    @ApiModelProperty(value = "金额")
    private String jine;
    /**
     * 分摊系数账单金额
     */
    @ApiModelProperty(value = "分摊系数账单金额")
    private String ftxszdje;
    /**
     * 校验电费列
     */
    @ApiModelProperty(value = "校验电费列")
    private String jydfl;
    /**
     * 电费分摊_移动4g
     */
    @ApiModelProperty(value = "电费分摊_移动4g")
    private String dfftYd4g;
    /**
     * 电费分摊_联通4g
     */
    @ApiModelProperty(value = "电费分摊_联通4g")
    private String dfftLt4g;
    /**
     * 电费分摊_电信4g
     */
    @ApiModelProperty(value = "电费分摊_电信4g")
    private String dfftDx4g;
    /**
     * 电费分摊_拓展业务
     */
    @ApiModelProperty(value = "电费分摊_拓展业务")
    private String dfftTzyw;
    /**
     * 电费分摊_移动5g
     */
    @ApiModelProperty(value = "电费分摊_移动5g")
    private String dfftYd5g;
    /**
     * 电费分摊_联通5g
     */
    @ApiModelProperty(value = "电费分摊_联通5g")
    private String dfftLt5g;
    /**
     * 电费分摊_电信5g
     */
    @ApiModelProperty(value = "电费分摊_电信5g")
    private String dfftDx5g;
    /**
     * 电费分摊_合计电费
     */
    @ApiModelProperty(value = "电费分摊_合计电费")
    private String dfftHjdf;
    /**
     * 电量分摊_移动4g
     */
    @ApiModelProperty(value = "电量分摊_移动4g")
    private String dlftYd4g;
    /**
     * 电量分摊_联通4g
     */
    @ApiModelProperty(value = "电量分摊_联通4g")
    private String dlftLt4g;
    /**
     * 电量分摊_电信4g
     */
    @ApiModelProperty(value = "电量分摊_电信4g")
    private String dlftDx4g;
    /**
     * 电量分摊_拓展业务
     */
    @ApiModelProperty(value = "电量分摊_拓展业务")
    private String dlftTzyw;
    /**
     * 电量分摊_移动5g
     */
    @ApiModelProperty(value = "电量分摊_移动5g")
    private String dlftYd5g;
    /**
     * 电量分摊_联通5g
     */
    @ApiModelProperty(value = "电量分摊_联通5g")
    private String dlftLt5g;
    /**
     * 电量分摊_电信5g
     */
    @ApiModelProperty(value = "电量分摊_电信5g")
    private String dlftDx5g;
    /**
     * 电量分摊_合计电量
     */
    @ApiModelProperty(value = "电量分摊_合计电量")
    private String dlftHjdf;
    /**
     * 分摊后电费(含税不含农网费)4G_移动
     */
    @ApiModelProperty(value = "分摊后电费(含税不含农网费)4G_移动")
    private String fthdfYd4g;
    /**
     * 分摊后电费(含税不含农网费)4G_联通
     */
    @ApiModelProperty(value = "分摊后电费(含税不含农网费)4G_联通")
    private String fthdfLt4g;
    /**
     * 分摊后电费(含税不含农网费)4G_电信
     */
    @ApiModelProperty(value = "分摊后电费(含税不含农网费)4G_电信")
    private String fthdfDx4g;
    /**
     * 分摊后电费(含税不含农网费)4G_拓展业务
     */
    @ApiModelProperty(value = "分摊后电费(含税不含农网费)4G_拓展业务")
    private String fthdfTzyw;
    /**
     * 分摊后电费(含税不含农网费)5G_移动
     */
    @ApiModelProperty(value = "分摊后电费(含税不含农网费)5G_移动")
    private String fthdfYd5g;
    /**
     * 分摊后电费(含税不含农网费)5G_联通
     */
    @ApiModelProperty(value = "分摊后电费(含税不含农网费)5G_联通")
    private String fthdfLt5g;
    /**
     * 分摊后电费(含税不含农网费)5G_电信
     */
    @ApiModelProperty(value = "分摊后电费(含税不含农网费)5G_电信")
    private String fthdfDx5g;
    /**
     * 分摊后农网费_移动
     */
    @ApiModelProperty(value = "分摊后农网费_移动")
    private String fthnwfYd;
    /**
     * 分摊后农网费_联通
     */
    @ApiModelProperty(value = "分摊后农网费_联通")
    private String fthnwfLt;
    /**
     * 分摊后农网费_电信
     */
    @ApiModelProperty(value = "分摊后农网费_电信")
    private String fthnwfDx;
    /**
     * 分摊后农网费_拓展业务
     */
    @ApiModelProperty(value = "分摊后农网费_拓展业务")
    private String fthnwfTzyw;
    /**
     * 分摊后农网费_合计
     */
    @ApiModelProperty(value = "分摊后农网费_合计")
    private String fthnwfHj;
    /**
     * 税负因子_移动4G税负因子
     */
    @ApiModelProperty(value = "税负因子_移动4G税负因子")
    private String sfyzYd4g;
    /**
     * 税负因子_联通4G税负因子
     */
    @ApiModelProperty(value = "税负因子_联通4G税负因子")
    private String sfyzLt4g;
    /**
     * 税负因子_电信4G税负因子
     */
    @ApiModelProperty(value = "税负因子_电信4G税负因子")
    private String sfyzDx4g;
    /**
     * 税负因子_移动5G税负因子
     */
    @ApiModelProperty(value = "税负因子_移动5G税负因子")
    private String sfyzYd5g;
    /**
     * 税负因子_联通5G税负因子
     */
    @ApiModelProperty(value = "税负因子_联通5G税负因子")
    private String sfyzLt5g;
    /**
     * 税负因子_电信5G税负因子
     */
    @ApiModelProperty(value = "税负因子_电信5G税负因子")
    private String sfyzDx5g;
    /**
     * 税负因子_税负因子总计
     */
    @ApiModelProperty(value = "税负因子_税负因子总计")
    private String sfyzZj;
    /**
     * 税负因子_移动4G分摊
     */
    @ApiModelProperty(value = "税负因子_移动4G分摊")
    private String sfyzYd4gFt;
    /**
     * 税负因子_联通4G分摊
     */
    @ApiModelProperty(value = "税负因子_联通4G分摊")
    private String sfyzLt4gFt;
    /**
     * 税负因子_电信4G分摊
     */
    @ApiModelProperty(value = "税负因子_电信4G分摊")
    private String sfyzDx4gFt;
    /**
     * 税负因子_拓展能源
     */
    @ApiModelProperty(value = "税负因子_拓展能源")
    private String sfyzTznyFt;
    /**
     * 税负因子_移动5G分摊
     */
    @ApiModelProperty(value = "税负因子_移动5G分摊")
    private String sfyzYd5gFt;
    /**
     * 税负因子_联通5G分摊
     */
    @ApiModelProperty(value = "税负因子_联通5G分摊")
    private String sfyzLt5gFt;
    /**
     * 税负因子_电信5G分摊
     */
    @ApiModelProperty(value = "税负因子_电信5G分摊")
    private String sfyzDx5gFt;
    /**
     * 税负因子_最终分摊合计
     */
    @ApiModelProperty(value = "税负因子_最终分摊合计")
    private String sfyzFthj;
    /**
     * 一站多表
     */
    @ApiModelProperty(value = "一站多表")
    private String yzdb;
    /**
     * 一表多站
     */
    @ApiModelProperty(value = "一表多站")
    private String ybdz;
    /**
     * 备注(一表一站)
     */
    @ApiModelProperty(value = "备注(一表一站)")
    private String bzybyz;
    /**
     * 钉钉流程编号
     */
    @ApiModelProperty(value = "钉钉流程编号")
    private String ddlcbh;
    /**
     * 网格负责人
     */
    @ApiModelProperty(value = "网格负责人")
    private String wgfzr;


}
