package org.springblade.common.tool;

import com.alibaba.excel.converters.Converter;
import com.alibaba.excel.enums.CellDataTypeEnum;
import com.alibaba.excel.metadata.CellData;
import com.alibaba.excel.metadata.GlobalConfiguration;
import com.alibaba.excel.metadata.property.ExcelContentProperty;

public class NullToZeroConverter implements Converter<Double> {

	/**
	 * 回到 Java 中的对象类型
	 *
	 * @return 支持 Java 类
	 */
	@Override
	public Class supportJavaTypeKey() {
		return Double.class;
	}

	/**
	 * * 返回 excel 中的对象枚举
	 * * @return 支持 {@link Cell DataTypeEnum}
	 * */
	@Override
	public CellDataTypeEnum supportExcelTypeKey() {
		return CellDataTypeEnum.STRING;
	}

	/**
	 * 将excel对象转换为Java对象
	 *
	 * @param cellData
	 * Excel 单元格数据。NotNull。
	 * @param contentProperty
	 * 内容属性。可空。
	 * @param globalConfiguration
	 * 全局配置。NotNull。
	 * @return 要放入 Java 对象的数据
	 * @抛出异常
	 *             例外。
	 */
	@Override
	public Double convertToJavaData(CellData cellData, ExcelContentProperty contentProperty, GlobalConfiguration globalConfiguration) throws Exception {


		String v = "";
		if(cellData.getType().name().equals("STRING")){
			v = cellData.getStringValue();
		}else{
			v = cellData.getNumberValue()+"";
		}
		System.out.println(v);
		if("".equals(v)){
			return 0d;
		}else{
			return Double.parseDouble(v);
		}
	}


	/**
	 * 将 Java 对象转换为 excel 对象
	 *
	 * @参数值
	 * Java 数据.NotNull。
	 * @param contentProperty
	 * 内容属性。可空。
	 * @param globalConfiguration
	 * 全局配置。NotNull。
	 * @return 数据放入 Excel
	 * @抛出异常
	 *             例外。
	 */
	@Override
	public CellData convertToExcelData(Double value, ExcelContentProperty contentProperty, GlobalConfiguration globalConfiguration) throws Exception {
		return new CellData<>(null == value?"":value);
	}
}
