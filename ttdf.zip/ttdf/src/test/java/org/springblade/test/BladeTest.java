package org.springblade.test;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springblade.core.test.BladeBootTest;
import org.springblade.core.test.BladeSpringExtension;
import org.springblade.modules.desk.service.INoticeService;
import org.springframework.beans.factory.annotation.Autowired;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * Blade单元测试
 *
 * @author Chill
 */
@ExtendWith(BladeSpringExtension.class)
@BladeBootTest(appName = "blade-runner", profile = "test")
public class BladeTest {

	@Autowired
	private INoticeService noticeService;

	@Test
	public void contextLoads() {
		Long count = noticeService.count();
		System.out.println("notice数量：[" + count + "] 个");
	}


	public static void main(String[] args) throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy年M月d");

		Date date = sdf.parse("2023年5月1日");


		Calendar calendar=Calendar.getInstance();

		calendar.setTime(date);
		calendar.add(Calendar.MONTH, -1);

		Date date1 = calendar.getTime();

		SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy/M/d");
		System.out.println(sdf1.format(date));
		System.out.println("上个月第一天："+sdf1.format(date1));

		int days = (int) ((date.getTime() - date1.getTime()) / (24 * 60 * 60 * 1000));
		System.out.println(days);


	}
}
