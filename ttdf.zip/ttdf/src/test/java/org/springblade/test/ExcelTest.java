package org.springblade.test;

import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.read.builder.ExcelReaderBuilder;
import org.junit.jupiter.api.Test;
import org.springblade.modules.ttdf.service.ITzftxxService;
import org.springblade.modules.ttdf.service.impl.TzftxxServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;

@Component
public class ExcelTest {
	@Autowired
	private ITzftxxService tzftxxService;
	@Test
	public void test(){
		File file=new File("D:\\project\\test\\test.xlsx");
		String filename = file.getName();
		if (StringUtils.isEmpty(filename)) {
			throw new RuntimeException("请上传文件!");
		}
		if ((!StringUtils.endsWithIgnoreCase(filename, ".xls") && !StringUtils.endsWithIgnoreCase(filename, ".xlsx"))) {
			throw new RuntimeException("请上传正确的excel文件!");
		}
		InputStream inputStream;
		try {
			tzftxxService.count();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
